
var express = require('express'),
    socketio = require('socket.io');

var userManager = require('./userManager').UserManager();
var touch2Game = require('./touch2Game');
var rankManager = require('./touch2rank').getPlayerRankManager();

var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

var touch2GameServer = {
        rooms:{},
        lobbyName: '[touch2lobby]',
        
        // lookup room based on socket id
        socketRoomMap:{},
        
        findRoom:function(roomId) {
            var room = this.rooms[roomId];
            if (room==null || room == undefined) {
                return null;
            }
            
            return room;
        },
        
        createRoom:function(uid, roomId, socket) {
            var room = {};
//            room.player1 = uid;
            room.id = roomId;
            room.ready = false;
            room.game = touch2Game.createGame();
            room.game.init();
            room.game.addPlayer(uid);
            
            socket.leave(touch2GameServer.lobbyName);
            socket.join(room.id);
            this.rooms[room.id] = room;

            
            this.socketRoomMap[socket.id] = {roomid: room.id, uid:uid};

            socket.emit('WAIT_PLAYER',{'roomId':room.id});
        },
        
        removeRoom: function(roomId) {
          if (this.rooms[roomId]!=null) {
              delete this.rooms[roomId];
//              this.rooms[roomId] = null;
          }  
        },
        
        joinRoom:function(uid, roomId, socket) {
          var room = this.rooms[roomId];
          if (room==null || room == undefined) {
              return;
          }

          if(room.game.players[uid]!=null && room.game.players[uid]!=undefined) {
              // player already exists
              return;
          }
          
          socket.join(room.id);
          this.socketRoomMap[socket.id] = {roomid: room.id, uid:uid};
/*
          if (room.player2 != undefined && room.player2!=null) {
              // join as guest
              var data = this.getRoomData(room);
              var msg = JSON.stringify({
                  'cmd':'JOIN_AS_GUEST',
                  'data':data
              });
              socket.send(msg);

              return;
          }
*/          
          // player 2 is not defined. create player2 and start game
//          room.player2=uid;
          
          room.game.addPlayer(uid);
          room.game.dataReady = false;

//          room.game.player1.ready = true;
//          room.game.player2.ready = true;
          
          room.ready = false;
          server.broadcast(socket, roomId, {
              'cmd':'USER_JOIN',
              'roomId':roomId,
              'userid':uid
          }, true);

        },
        
        leaveRoom:function(roomid, userid) {
            console.log(userid + " leave room " + roomid);
            var room = this.rooms[roomid];
            if (room==null || room == undefined) {
                return;
            }
            
            room.game.removePlayer(userid);
            
            var i = 0;
            for(i in room.game.players) {
                ++i;
            }
            console.log('players left ' + i);
            if (i==0) {
                this.removeRoom(roomid);
            }
            
        },
        
        getRoomData:function(room) {
            var data = {
                    'room_id': room.id,
                    'board':room.game.board,
                    'bgid':room.game.backgroundId,
                    'ballid': room.game.ballId,
                    'setid': room.game.setId,
                    'expectValue': room.game.expectNumber,
                    'players':room.game.players
            };
            
            return data;
  
        },
        
        getRoomInfo:function(roomid) {
            var room = this.rooms[roomid];
            if (room==null || room == undefined) {
                return null;
            }
            
            return this.getRoomData(room);
        },
        
        startGame:function(room, clientSocket) {
            console.log('*************game start for ' + room.id);
            var data = this.getRoomData(room);
            
            server.broadcast(clientSocket, room.id, {
                'cmd':'START_GAME',
                'data':data
            });
            /*
            var msg = JSON.stringify(data);
            clientSocket.broadcast.to(room.id).send(msg);
            clientSocket.send(msg);
            */
            console.log('*************broadcast done for ' + room.id);
//            clientSocket.send('START_GAME');
//            gameServer.sockets.in(room.id).emit('START_GAME',room.game.board);
            
        },
        
        onUserClick:function(roomId, uid, index) {
            console.log(roomId);
            var room = this.rooms[roomId];

            if (room==null || room==undefined) {
                return null;
            }

            var result = room.game.onUserClick(uid, index);
            if (result == null || result.expectNumber == undefined) {
                return result;
            }
            
            if (result.expectNumber < 0) {
                room.ready = false;
                // game is done. find the winner and increase the exp
                this.updatePlayerRank(room.game.players);
            }
            
            return result;
        },
        
        updatePlayerRank:function(players) {
            // find top 2
            var player1 = 0;
            var score1 = -99999;
            var player2 = 0;
            var score2 = -99999;

            var count = 0;
            for(i in players) {
                ++count;
                var player = players[i];
                if (player.score> score1) {
                    player1 = player.id;
                    score1 = player.score;
                    continue;
                } else if (player.score>score2) {
                    player2 = player.id;
                    score2 = player.score;
                    continue;
                }
            }
            
            var exp1 = count - 1;
            var exp2 = count - 2;

            rankManager.update(player1, 'touch2', exp1,function(doc){console.log(doc);});
            rankManager.update(player2, 'touch2', exp2,function(doc){console.log(doc);});
            
        },
        
        onRestartGame:function(roomId,uid) {
            var room = this.rooms[roomId];

            if (room==null || room==undefined) {
                return null;
            }
            
            
            if (!room.ready) {
                room.game.reset();
                room.ready = true;
            }
            
            /*
            console.log(room.game.player1);
            console.log(room.game.player2);
            */
            
            room.game.setPlayerReady(uid);
            /*
            if (room.game.player1.id==uid) {
                room.game.player1.ready = true;
            } else if (room.game.player2.id == uid) {
                room.game.player2.ready = true;
            }
            */
            
            if (room.game.gameReady()) {
                console.log('game is ready');
                return room;
            }
            
            return null;
        },
        
        updateAllRooms:function(socket, echo, sendToAll) {
            
            var rooms=[];
            
            for(id in touch2GameServer.rooms) {
                var room = touch2GameServer.rooms[id];
                
                if (room ==undefined || room==null) {
                    continue;
                }
                
                rooms.push({
                    id:room.id,
                    players:room.game.players,
                });
            }
            
            var result= {
                    'cmd': 'UPDATE_ROOMS',
                    'rooms': rooms
            };

            if (sendToAll == false) {
                socket.send(JSON.stringify(result));
            } else {
                server.broadcast(socket, touch2GameServer.lobbyName, result, echo);
            }
//            server.touch2Server.emit('GAME_ROOMS',result);
        }
        
        
};

var server = {

io: null,
app: null,

touch2Server:null,
count: 0,

broadcast: function(socket, roomId, obj, echo) {
        var msg = JSON.stringify(obj);
        socket.broadcast.to(roomId).send(msg);
        if (echo==undefined || echo==true) {
            console.log('echo to client');
            socket.send(msg);
        }
},

start: function(port) {

    userManager.init();
    rankManager.init();
//    userManager.removeAll();
    this.app = express.createServer();
    this.app.use(express.bodyParser());
    this.app.listen(port);
    this.app.get('/check',this.check);
    this.app.post('/nodeservice',this.serviceHandler);
    this.io = socketio.listen(this.app);
    console.log('start listening');
    
    this.io.enable('browser client minification');  // send minified client
    this.io.enable('browser client etag');          // apply etag caching logic based on version number
    this.io.enable('browser client gzip');          // gzip the file
//    this.io.set('log level', 1);                    // reduce logging
    this.io.set('transports', [                     // enable all transports (optional if you want flashsocket)
                'websocket'
              , 'flashsocket'
              , 'htmlfile'
              , 'xhr-polling'
              , 'jsonp-polling'
    ]);


    this.touch2Server = this.io.of('/touch2').on('connection', function(socket){
        console.log("player connected " + socket.id);
        socket.emit('CONNECTED',{});

        socket.on('CREATE_NEW_ROOM', function(data) {
           if (server.validateRoomId(data.roomId) && touch2GameServer.findRoom(data.roomId)== null) {
               console.log('create room ' + data.roomId);
               touch2GameServer.createRoom(data.uid, data.roomId, socket);  
               touch2GameServer.updateAllRooms(socket, false);
           }
        });
        
        socket.on('GET_ROOMS', function(data) {
            socket.join(touch2GameServer.lobbyName);
            touch2GameServer.updateAllRooms(socket);

        });
        
        socket.on('JOIN_ROOM', function(data){
           console.log('on socket:JOIN_GAME');

           touch2GameServer.joinRoom(data.uid, data.roomId, socket);
        });
        
        socket.on('EXIT_GAME', function(data){
//            console.log('*******************remove room : ' + data.roomId );
//            touch2GameServer.removeRoom(data.roomId);
//            server.broadcast(socket, data.roomId, {'cmd':'LEAVE_ROOM'});
            // update all other clients in the lobby
//            touch2GameServer.updateAllRooms(socket, false);
            socket.leave(data.roomId);
            
            var info = touch2GameServer.socketRoomMap[socket.id];
            if (info != null && info != undefined) {
                touch2GameServer.leaveRoom(info.roomid, info.uid);
                server.broadcast(socket, info.roomid, {
                    'cmd':'UPDATE_ROOM_INFO',
                    'room':touch2GameServer.getRoomInfo(info.roomid)
                }, false);
            }
            
            socket.join(touch2GameServer.lobbyName);

            touch2GameServer.updateAllRooms(socket, true);
            
        });
        
        /*
        socket.on('LEAVE_ROOM', function(data){
            socket.leave(data.roomId);

            var info = touch2GameServer.socketRoomMap[socket.id];
            if (info != null && info != undefined) {
                touch2GameServer.leaveRoom(info.roomid, info.uid);
                server.broadcast(socket, info.roomid, {
                    'cmd':'UPDATE_ROOM_INFO',
                    'room':touch2GameServer.getRoomInfo(info.roomid)
                }, false);
            }
            
            touch2GameServer.updateAllRooms(socket, false, false);

            socket.join(touch2GameServer.lobbyName);
            // update each individual cients in the removed room
        });
        */
        
        socket.on('disconnect', function () {
            //game room ALWASY contains only 2 players to update scores.
            //socket "room" is only for broadcasting and we rely on socket io itself to remove.
            // The only case is when player1 or player2 disconnect, the room will be moved to empty room again and wait for player
            console.log('socket closed: ' + socket.id);
            var info = touch2GameServer.socketRoomMap[socket.id];
            if (info != null && info != undefined) {
                touch2GameServer.leaveRoom(info.roomid, info.uid);
//                touch2GameServer.removeRoom(roomId);
                server.broadcast(socket, info.roomid, {
                    'cmd':'UPDATE_ROOM_INFO',
                    'room':touch2GameServer.getRoomInfo(info.roomid)
                }, false);
                
//                server.broadcast(socket, roomId, {'cmd':'LEAVE_ROOM'});
            }
          });
        
        socket.on('RESTART_GAME', function(data){
            console.log('ON restart game');
            var room = touch2GameServer.onRestartGame(data.room_id, data.uid);
            if (room != null) {
                console.log(room);
                console.log("**********restart game *****************");
                touch2GameServer.startGame(room, socket);
            }
        });
        
        socket.on('CHAT_MESSAGE', function(data){
            var uid = data.uid;
            var message = data.value;
            userManager.findUserById(uid, function(doc) {
                server.broadcast(socket, data.room_id, {
                   'cmd': 'CHAT_MESSAGE',
                   'user':doc,
                   'message':message
                });
            });
        });
        
        socket.on('USER_CLICK',function(data){
            console.log(data.uid + ' clicked on ' + data.index);
            var result = touch2GameServer.onUserClick(data.room_id, data.uid,data.index);
            if(result != null) {
                if (result.expectNumber != undefined) {
                    var data ={
                            'cmd':'REMOVE_NUMBER',
                            'index':data.index,
                            'expectValue': result.expectNumber,
                            'players': result.players
                       };
                } else {
                    var data ={
                            'cmd':'UPDATE_SCORE',
                            'players': result.players
                    };
                }
                
                server.broadcast(socket,data.room_id,data);
            }
        });
       
    });

},


validateRoomId: function(roomId) {
    var invalidLetters=['<','>','/','\\', '"','&','[',']'];
    for(i in invalidLetters){
        var c = invalidLetters[i];
        if (roomId.indexOf(c)>=0){
            return false;
        }
    }
    
    return true;
},

check:function(req, resp) {
    resp.send('EVERYTHING is fine');
},

serviceHandler: function(req, resp) {
    var payload = JSON.parse(req.body.data_payload);
    switch(req.body.method) {

        case 'JOIN_GAME':
            console.log('JOIN_GAME: ' + payload.uid);
            userManager.findUserById(payload.uid, function(doc) {
                console.log(doc);
                server.touchnumberGame.emit('JOIN_GAME', doc);
            });
            break;
        /*
        case 'JOIN_TOUCH2':
            console.log('JOIN_GAME: ' + payload.uid);
            userManager.findUserById(payload.uid, function(doc) {
                resp.send(JSON.stringify(doc));
            });
            break;
        */
    }	

},

};

server.start(54322);
