var mongoose = require('mongoose'),
    Schema = mongoose.Schema;


exports.UserManager=userManager;

var userManager = {

userSchema: new Schema({
    username: {type:String},
    password: {type:String,default:null},
    regtime: {type:Date, default: Date.now},
    
    weibo_id: {type:String,default:null},
    weibo_token: {type:String,default:null},
    
    qq_id: {type: String,default:null},
    qq_token: {type: String,default:null},
    
    rr_id: {type: String,default:null},
    rr_token: {type: String,default:null},
    
    fb_id: {type: String,default:null},
    fb_token: {type: String,default:null}
}),

userModel: null,
db:null,

init: function() {

    this.db = mongoose.connect('mongodb://localhost/localuser');
    this.userModel = mongoose.model('UserModel', this.userSchema);
},


removeAll:function() {
    this.userModel.find({},function(err,docs){
         for(i in docs) {
             docs[i].remove();
         }
    });

},

addNewUser:function(username, password) {

    var user = new this.userModel();
    user.username = username;
    user.password = password;
    
    user.save(function(err, newUser){ 
        console.log(newUser); 
        var value = JSON.stringify(newUser);
        resp.send(value);
    });
},

findUserByName:function(name, cbExist, cbNotExist) {

    this.userModel.findOne({'username':name},function(err,doc){
         if (doc != null) {
            cbExist(doc);
         } else {
            cbNotExist();
         }
    });

},

findUserById: function(id, callback) {
    this.userModel.findOne({'_id':id},function(err,doc){
        if (doc==null) {
            return;
        }
        doc.password='';
        callback(doc);
   });  
    
},

registerUser:function(username,password,resp) {
    var _this = this;
    
    this.findUserBy
    
    this.findUser(username, extId, type,
                  function(user) {
                      // TODO: update for 3rd party data
                      resp.send(JSON.stringify(user));
                  },  
                  function() {
                      _this.addNewUser(username,password,extId,type,image,gender,profile,resp);
                  });
}

};