var mongoose = require('mongoose'),
    Schema = mongoose.Schema;


exports.UserManager=function() {
    return userManager;
}

var userManager = {

userSchema: new Schema({
    username: {type:String},
    password: {type:String,default:null},
    extId: {type:String, default:null},
    type: {type:String, default:'myjoyspace'},
    image: {type:String,default:''},
    gender: {type:String},
    profile: {type:String},
    regtime: {type:Date, default: Date.now}
}),

userModel: null,
db:null,

init: function() {

    this.db = mongoose.connect('mongodb://localhost/user');
    this.userModel = mongoose.model('UserModel', this.userSchema);
},


removeAll:function() {
    this.userModel.find({},function(err,docs){
         for(i in docs) {
             docs[i].remove();
         }
    });

},

addNewUser:function(username, password, extId, type, image, gender, profile, resp) {

    var user = new this.userModel();
    user.username = username;
    user.password = password;
    user.extId = extId;
    if (type != null) {
        user.type = type;
    }
    user.image = image;
    user.gender = gender;
    user.profile = profile;
    
    user.save(function(err, newUser){ 
        console.log(newUser); 
        var value = JSON.stringify(newUser);
        resp.send(value);
    });
},

findLocalUserByName:function(name, cbExist, cbNotExist) {

    this.userModel.findOne({'username':name, extId:null, 'type':'myjoyspace'},function(err,doc){
         if (doc != null) {
            cbExist(doc);
         } else {
           cbNotExist();
         }
    });

},

findExtUserById: function(type,extId, cbExist, cbNotExist) {

    this.userModel.findOne({'extId':extId, 'type':type},function(err,doc){
         if (doc!=null) {
            cbExist(doc);
         } else {
           cbNotExist();
         }
    });
},

findUser:function(username,extId,type, cbExist, cbNotExist) {
    if (extId == null) {
          this.findLocalUserByName(username, cbExist, cbNotExist);
    } else {
          this.findExtUserById(type, extId, cbExist, cbNotExist);
    }
},

findUserById: function(id, callback) {
    this.userModel.findOne({'_id':id},function(err,doc){
        if (doc==null) {
            return;
        }
        var user = {};
        user._id = doc._id;
        user.extId = doc.extId;
        user.gender = doc.gender;
        user.image = doc.image;
        user.profile = doc.profile;
        user.type = doc.type;
        user.username = doc.username;
        callback(user);
   });  
    
},

registerUser:function(username,password,extId,type,image,gender,profile,resp) {
    var _this = this;
    this.findUser(username, extId, type,
                  function(user) {
                      // TODO: update for 3rd party data
                      user.image = image;
                      user.profile = profile;
                      user.save(function(err){});
                      
                      resp.send(JSON.stringify(user));
                  },  
                  function() {
                      _this.addNewUser(username,password,extId,type,image,gender,profile,resp);
                  });
}

};