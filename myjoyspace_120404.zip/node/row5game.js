
exports.createGame=function() {
    return new row5Game();
};


function row5Game() {

    this.players = {};
    this.playerCount = 0;
    this.maxPlayers = 2;
    
    this.init = function() {
        this.reset();
    };
    
    this.gameReady = function() {
//        return this.player1.ready && this.player2.ready;  
        for(i in this.players){
            if (this.players[i].ready == false){
                return false;
            }
        }
        
        return true;
    };
    
    this.setPlayerReady = function(playerId){
      if (this.players[playerId]!= null && this.players[playerId]!=undefined){
          this.players[playerId].ready = true;
      }  
    };
    
    this.addPlayer = function(playerId){
/*
        if (this.playerCount>=this.maxPlayers) {
            return;
        }
*/        
        this.playerCount++;
        var color = 1;
        if (this.playerCount==2) {
            color=2;
        } 
        this.players[playerId]={
          id:playerId,
          color:color,
          ready:false
        };
        
    };
    
    this.removePlayer = function(playerId){
        if (this.players[playerId]!=null && this.players[playerId]!=undefined){
            delete this.players[playerId];
        }  
      };

    this.resetPlayers = function() {
        var color = -1;
        
        for(i in this.players){
            if (color<0) {
            color = Math.floor(Math.random()*2) + 1;
            } else {
                color = 3-color;
            }
            
            this.players[i].color = color;
            this.players[i].ready = 0;
        }
    };
    
    this.beforeStart = function() {
        var color = -1;
        
        for(i in this.players){
            if (color<0) {
            color = Math.floor(Math.random()*2) + 1;
            } else {
                color = 3-color;
            }
            this.players[i].color = color;
        }
        
    };
    
    this.reset=function() {

        this.resetPlayers();
        
    };
    
    this.onUserClick=function(uid, index) {
      
        return null;
        
    };
    
    this.getGameInfo=function() {
        console.log(this.players);
        return {'players':this.players};
    };
    
};