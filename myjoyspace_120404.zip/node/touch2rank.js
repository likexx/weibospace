var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

exports.getPlayerRankManager=function() {
    
    return playerRankManager;
};

var playerRankManager = {

rankSchema: new Schema({

    userid:{type:String, index:true},
    game:{type:String, index:true},
    exp: {type:Number,index:true}
}),

record: null,
db: null,

init: function() {
    this.db = mongoose.connect('mongodb://localhost/playerrank');
    this.record = mongoose.model('PlayerRank', this.rankSchema);
},

update: function(userid, gamename,exp_diff, callback) {
    
    if (userid==0 || userid=='0') {
        return;
    }

    this.record.findOne({'game':gamename, 'userid':userid},function(err,doc){
        if (doc != null && doc != undefined) {
            doc.exp += exp_diff;
            doc.save(function(err, rank){
                callback(rank);
            });
        } else {
          playerRankManager.add(userid, gamename, exp_diff, callback);
        }
   });
    
    
},

add: function(userid, gamename, exp,callback) {
    var r = new this.record();
    r.userid = userid;
    r.game = gamename;
    r.exp = exp;
    
    r.save(function(err, newRecord){ 
        callback(newRecord);
    });
},


findRecords: function(gamename, callback) {
  
    this.record.find({})
               .sort('exp', -1)
               .limit(100)
               .execFind(function(err, records){
                   callback(records);
               });
    
},

deleteRank:function(id){
    this.record.find({'_id':id}, function(err, records){
        for (i in records) {
            records[i].remove();
        }
    });
    
}


};
