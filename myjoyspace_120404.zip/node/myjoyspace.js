
var express = require('express'),
    socketio = require('socket.io');

var userManager = require('./userManager').UserManager();
var touch2Game = require('./touch2Game');
var row5Game = require('./row5game');
var rankManager = require('./touch2rank').getPlayerRankManager();


var mongoose = require('mongoose'),
    Schema = mongoose.Schema;


var singleGameManager = {

recordSchema: new Schema({

    userid:{type:String, index:true},
    game:{type:String, index:true},
    score: {type:Number,index:true},
    time: {type:Date, default:Date.now}

}),

record: null,
db: null,

init: function() {
    this.db = mongoose.connect('mongodb://localhost/singlegame');
    this.record = mongoose.model('SingleGameRecord', this.recordSchema);
},

add: function(userid, gamename, score, time, callback) {
    var r = new this.record();
    r.userid = userid;
    r.game = gamename;
    r.score = score;
    
    r.save(function(err, newRecord){ 
        callback(newRecord);
    });
},

//
// remove records earlier than the given time
//
removeAll: function(latestTime) {
    this.record.find({},function(err,docs) {
                    
                     for(i in docs) {
                         docs[i].remove();
                     }
                });
},

findUserRecords: function(userid, gamename, callback) {

    this.record.where('userid',userid).
                where('game',gamename).
                find(function(err,docs) {
                    var result = [];
                    for(i in docs) {
                        result.push(docs[i]);
                    }
                    callback(result);
                });

},

findRecords: function(gamename, callback) {
  
    this.record.find({'game':gamename})
               .sort('score', 1)
               .limit(100)
               .execFind(function(err, records){
                   callback(records);
               });
    
},

getScoreRank: function(gamename, score, callback) {
    this.record.count({'game': gamename, 'score':{$lte:score}}, function(err, count){
        callback(count);
    });  
}

};

var touch2GameServer = {
        rooms:{},
        lobbyNames: {
            'touch2':'[touch2lobby]',
            'row5':'[row5lobby]'
        },
        
        // lookup room based on socket id
        socketRoomMap:{},
        
        findRoom:function(roomId) {
            var room = this.rooms[roomId];
            if (room==null || room == undefined) {
                return null;
            }
            
            return room;
        },
        
        createRoom:function(uid, roomId, socket, max,game) {
            var room = {};
            if (game==undefined) {
                game='touch2';
            }
//            room.player1 = uid;
            room.id = roomId;
            room.ready = false;
            room.gameStarted = false;
            if (max==undefined) {
                room.max = 100;
            } else {
                room.max = max;
            }
            
            if (game == 'row5') {
                room.game = row5Game.createGame();
                room.game.init();
                room.game.addPlayer(uid);
            } else {
                room.game = touch2Game.createGame();
                room.game.init();
                room.game.addPlayer(uid);
            }
            
            socket.leave(touch2GameServer.lobbyNames[game]);
            socket.join(room.id);
            this.rooms[room.id] = room;

            
            this.socketRoomMap[socket.id] = {roomid: room.id, uid:uid};

            socket.emit('WAIT_PLAYER',{'roomId':room.id});
        },
        
        removeRoom: function(roomId) {
          if (this.rooms[roomId]!=null) {
              delete this.rooms[roomId];
//              this.rooms[roomId] = null;
          }  
        },
        
        joinRoom:function(uid, roomId, socket) {
          var room = this.rooms[roomId];
          if (room==null || room == undefined) {
              return;
          }

          if(room.game.players[uid]!=null && room.game.players[uid]!=undefined) {
              // player already exists
              console.log("player exists");
              return;
          }
          
          socket.join(room.id);
          this.socketRoomMap[socket.id] = {roomid: room.id, uid:uid};
          
          room.game.addPlayer(uid);
          room.game.dataReady = false;

          room.ready = false;
          server.broadcast(socket, roomId, {
              'cmd':'USER_JOIN',
              'roomId':roomId,
              'userid':uid
          }, true);

        },
        
        leaveRoom:function(roomid, userid) {
            console.log(userid + " leave room " + roomid);
            var room = this.rooms[roomid];
            if (room==null || room == undefined) {
                return;
            }
            
            room.game.removePlayer(userid);
            
            var i = 0;
            for(i in room.game.players) {
                ++i;
            }
            console.log('players left ' + i);
            if (i==0) {
                this.removeRoom(roomid);
            }
            
        },
        
        getRoomData:function(room) {
            var data = room.game.getGameInfo();
            data['room_id'] = room.id;
            /*
            {
                    'room_id': room.id,
                    'board':room.game.board,
                    'bgid':room.game.backgroundId,
                    'ballid': room.game.ballId,
                    'setid': room.game.setId,
                    'expectValue': room.game.expectNumber,
                    'players':room.game.players
            };
            */
            return data;
  
        },
        
        getRoomInfo:function(roomid) {
            var room = this.rooms[roomid];
            if (room==null || room == undefined) {
                return null;
            }
            
            return this.getRoomData(room);
        },
        
        startGame:function(room, clientSocket) {
            console.log('*************game start for ' + room.id);
            if (room.game.beforeStart != undefined) {
                room.game.beforeStart();
            }
            room.gameStarted = true;
            var data = this.getRoomData(room);
            
            server.broadcast(clientSocket, room.id, {
                'cmd':'START_GAME',
                'data':data
            });
            /*
            var msg = JSON.stringify(data);
            clientSocket.broadcast.to(room.id).send(msg);
            clientSocket.send(msg);
            */
            console.log('*************broadcast done for ' + room.id);
//            clientSocket.send('START_GAME');
//            gameServer.sockets.in(room.id).emit('START_GAME',room.game.board);
            
        },
        
        onUserClick:function(roomId, uid, index) {
            console.log(roomId);
            var room = this.rooms[roomId];

            if (room==null || room==undefined) {
                return null;
            }

            var result = room.game.onUserClick(uid, index);
            if (result == null || result.expectNumber == undefined) {
                return result;
            }
            
            if (result.expectNumber < 0) {
                room.ready = false;
                // game is done. find the winner and increase the exp
                this.updatePlayerRank(room.game.players);
            }
            
            return result;
        },
        
        updatePlayerRank:function(players) {
            // find top 2
            var player1 = 0;
            var score1 = -99999;
            var player2 = 0;
            var score2 = -99999;

            var count = 0;
            for(i in players) {
                ++count;
                var player = players[i];
                if (player.score> score1) {
                    player1 = player.id;
                    score1 = player.score;
                    continue;
                } else if (player.score>score2) {
                    player2 = player.id;
                    score2 = player.score;
                    continue;
                }
            }
            
            var exp1 = count - 1;
            var exp2 = count - 2;

            rankManager.update(player1, 'touch2', exp1,function(doc){console.log(doc);});
            rankManager.update(player2, 'touch2', exp2,function(doc){console.log(doc);});
            
        },
        
        onRestartGame:function(roomId,uid) {
            var room = this.rooms[roomId];

            if (room==null || room==undefined) {
                return null;
            }
            
            
            if (!room.ready) {
                room.game.reset();
                room.ready = true;
            }
            
            room.game.setPlayerReady(uid);
            /*
            if (room.game.player1.id==uid) {
                room.game.player1.ready = true;
            } else if (room.game.player2.id == uid) {
                room.game.player2.ready = true;
            }
            */
            
            if (room.game.gameReady()) {
                console.log('game is ready');
                return room;
            }
            
            return null;
        },
        
        updateAllRooms:function(game, socket, echo, sendToAll) {
            
            var rooms=[];
            
            for(id in touch2GameServer.rooms) {
                var room = touch2GameServer.rooms[id];
                
                if (room ==undefined || room==null) {
                    continue;
                }
                
                rooms.push({
                    id:room.id,
                    players:room.game.players,
                });
            }
            
            var result= {
                    'cmd': 'UPDATE_ROOMS',
                    'rooms': rooms
            };

            if (sendToAll == false) {
                socket.send(JSON.stringify(result));
            } else {
//                server.broadcast(socket, touch2GameServer.lobbyName, result, echo);
                server.broadcast(socket, touch2GameServer.lobbyNames[game], result, echo);
            }
//            server.touch2Server.emit('GAME_ROOMS',result);
        }
        
        
};



var server = {

io: null,
app: null,
singleGameServer:null,
touch2Server:null,
row5Server:null,

broadcast: function(socket, roomId, obj, echo) {
    var msg = JSON.stringify(obj);
    socket.broadcast.to(roomId).send(msg);
    if (echo==undefined || echo==true) {
        console.log('echo to client');
        socket.send(msg);
    }
},

start: function(port) {

    userManager.init();
    singleGameManager.init();
    rankManager.init();
//    userManager.removeAll();
//    singleGameManager.removeAll(Date.now);
    this.app = express.createServer();
    this.app.use(express.bodyParser());
    this.app.listen(port);
    this.app.get('/check',this.check);
    this.app.post('/nodeservice',this.serviceHandler);
    this.io = socketio.listen(this.app);
    console.log('start listening');
    
    this.io.enable('browser client minification');  // send minified client
    this.io.enable('browser client etag');          // apply etag caching logic based on version number
    this.io.enable('browser client gzip');          // gzip the file
//    this.io.set('log level', 1);                    // reduce logging
    this.io.set('transports', [                     // enable all transports (optional if you want flashsocket)
                'websocket'
              , 'htmlfile'
              , 'flashsocket'
              , 'xhr-polling'
              , 'jsonp-polling'
    ]);


    this.singleGameServer = this.io.of('/singleplayer').on('connection', function(socket){
        
        console.log("socket :" + socket.id);
        
        socket.emit('CONNECTED',{});
       
    });
    

    this.row5Server = this.io.of('/row5').on('connection', function(socket){
        
        console.log("socket :" + socket.id);
        console.log("Row5 CONNECTED!!!!!");
        
        socket.emit('CONNECTED',{});
        
        socket.on('CREATE_NEW_ROOM', function(data) {
            var roomId= data.game==undefined ? data.roomId : (data.game + "_" + data.roomId); 
            
            if (data.max==undefined){
                data.max = 100;
            }
            
            if (server.validateRoomId(roomId) && touch2GameServer.findRoom(roomId)== null) {
                console.log('create room ' + roomId);
                touch2GameServer.createRoom(data.uid, roomId, socket, data.max, data.game);  
                touch2GameServer.updateAllRooms('row5',socket, false);
            }
         });
         
         socket.on('GET_ROOMS', function(data) {
             socket.join(touch2GameServer.lobbyNames['row5']);
             touch2GameServer.updateAllRooms('row5', socket);

         });
         
         socket.on('JOIN_ROOM', function(data){
            console.log('on socket:JOIN_GAME');
            var room = touch2GameServer.rooms[data.roomId];
            if (room==null || room == undefined || room.gameStarted == true) {
                return;
            }

            touch2GameServer.joinRoom(data.uid, data.roomId, socket);
         });
         
         socket.on('EXIT_GAME', function(data){
             socket.leave(data.roomId);
             
             var info = touch2GameServer.socketRoomMap[socket.id];
             if (info != null && info != undefined) {
                 touch2GameServer.leaveRoom(info.roomid, info.uid);
                 server.broadcast(socket, info.roomid, {
                     'cmd':'EXIT_GAME'
                 }, false);
             }
             
             socket.join(touch2GameServer.lobbyNames['row5']);

             touch2GameServer.updateAllRooms('row5', socket, true);
             
         });
                 
         socket.on('disconnect', function () {
             //game room ALWASY contains only 2 players to update scores.
             //socket "room" is only for broadcasting and we rely on socket io itself to remove.
             // The only case is when player1 or player2 disconnect, the room will be moved to empty room again and wait for player
             console.log('socket closed: ' + socket.id);
             var info = touch2GameServer.socketRoomMap[socket.id];
             if (info != null && info != undefined) {
                 touch2GameServer.leaveRoom(info.roomid, info.uid);
//                 touch2GameServer.removeRoom(roomId);
                 server.broadcast(socket, info.roomid, {
                     'cmd':'EXIT_GAME'
                 }, false);
//                 server.broadcast(socket, roomId, {'cmd':'LEAVE_ROOM'});
             }

             touch2GameServer.updateAllRooms('row5', socket, false);

           });
         
         socket.on('RESTART_GAME', function(data){
             console.log('ON restart game for ' + data.room_id);
             var room = touch2GameServer.onRestartGame(data.room_id, data.uid);
             if (room != null) {
                 //console.log(room);
                 console.log("**********restart game *****************");
                 touch2GameServer.startGame(room, socket);
             }
         });
         
         socket.on('CHAT_MESSAGE', function(data){
             var uid = data.uid;
             var message = data.value;
             userManager.findUserById(uid, function(doc) {
                 server.broadcast(socket, data.room_id, {
                    'cmd': 'CHAT_MESSAGE',
                    'user':doc,
                    'message':message
                 });
             });
         });
         
         socket.on('action',function(data){
             //console.log(data);
             
             server.broadcast(socket,data.roomId,{
                 'cmd':'ACTION',
                 'value':data.value
             });
         });
        
     });
        
       
   
    
    
    this.touch2Server = this.io.of('/touch2').on('connection', function(socket){
        console.log("player connected " + socket.id);
        socket.emit('CONNECTED',{});

        socket.on('CREATE_NEW_ROOM', function(data) {
           if (server.validateRoomId(data.roomId) && touch2GameServer.findRoom(data.roomId)== null) {
               console.log('create room ' + data.roomId);
               touch2GameServer.createRoom(data.uid, data.roomId, socket);  
               touch2GameServer.updateAllRooms('touch2', socket, false);
           }
        });
        
        socket.on('GET_ROOMS', function(data) {
            socket.join(touch2GameServer.lobbyNames['touch2']);
            touch2GameServer.updateAllRooms('touch2', socket);

        });
        
        socket.on('JOIN_ROOM', function(data){
           console.log('on socket:JOIN_GAME');

           touch2GameServer.joinRoom(data.uid, data.roomId, socket);
        });
        
        socket.on('EXIT_GAME', function(data){
//            console.log('*******************remove room : ' + data.roomId );
//            touch2GameServer.removeRoom(data.roomId);
//            server.broadcast(socket, data.roomId, {'cmd':'LEAVE_ROOM'});
            // update all other clients in the lobby
//            touch2GameServer.updateAllRooms(socket, false);
            socket.leave(data.roomId);
            
            var info = touch2GameServer.socketRoomMap[socket.id];
            if (info != null && info != undefined) {
                touch2GameServer.leaveRoom(info.roomid, info.uid);
                server.broadcast(socket, info.roomid, {
                    'cmd':'UPDATE_ROOM_INFO',
                    'room':touch2GameServer.getRoomInfo(info.roomid)
                }, false);
            }
            
            socket.join(touch2GameServer.lobbyNames['touch2']);

            touch2GameServer.updateAllRooms('touch2', socket, true);
            
        });
                
        socket.on('disconnect', function () {
            //game room ALWASY contains only 2 players to update scores.
            //socket "room" is only for broadcasting and we rely on socket io itself to remove.
            // The only case is when player1 or player2 disconnect, the room will be moved to empty room again and wait for player
            console.log('socket closed: ' + socket.id);
            var info = touch2GameServer.socketRoomMap[socket.id];
            if (info != null && info != undefined) {
                touch2GameServer.leaveRoom(info.roomid, info.uid);
//                touch2GameServer.removeRoom(roomId);
                server.broadcast(socket, info.roomid, {
                    'cmd':'UPDATE_ROOM_INFO',
                    'room':touch2GameServer.getRoomInfo(info.roomid)
                }, false);
//                server.broadcast(socket, roomId, {'cmd':'LEAVE_ROOM'});
            }

            touch2GameServer.updateAllRooms('touch2', socket, false);

          });
        
        socket.on('RESTART_GAME', function(data){
            console.log('ON restart game');
            var room = touch2GameServer.onRestartGame(data.room_id, data.uid);
            if (room != null) {
                //console.log(room);
                console.log("**********restart game *****************");
                touch2GameServer.startGame(room, socket);
            }
        });
        
        socket.on('CHAT_MESSAGE', function(data){
            var uid = data.uid;
            var message = data.value;
            userManager.findUserById(uid, function(doc) {
                server.broadcast(socket, data.room_id, {
                   'cmd': 'CHAT_MESSAGE',
                   'user':doc,
                   'message':message
                });
            });
        });
        
        socket.on('USER_CLICK',function(data){
            console.log(data.uid + ' clicked on ' + data.index);
            var result = touch2GameServer.onUserClick(data.room_id, data.uid,data.index);
            if(result != null) {
                if (result.expectNumber != undefined) {
                    var data ={
                            'cmd':'REMOVE_NUMBER',
                            'index':data.index,
                            'expectValue': result.expectNumber,
                            'players': result.players
                       };
                } else {
                    var data ={
                            'cmd':'UPDATE_SCORE',
                            'players': result.players
                    };
                }
                
                server.broadcast(socket,data.room_id,data);
            }
        });
       
    });

},

validateRoomId: function(roomId) {
    var invalidLetters=['<','>','/','\\', '"','&','[',']'];
    for(i in invalidLetters){
        var c = invalidLetters[i];
        if (roomId.indexOf(c)>=0){
            return false;
        }
    }
    
    return true;
},


check:function(req, resp) {
    resp.send('EVERYTHING is fine');
},

serviceHandler: function(req, resp) {
    var payload = JSON.parse(req.body.data_payload);
    switch(req.body.method) {

        case 'register':
            userManager.registerUser(payload.username,
                                     payload.password,
                                     payload.extId,
                                     payload.type,
                                     payload.image,
                                     payload.gender,
                                     payload.profile,
                                     resp);
            break;
        
        case 'finduserbyid':
            console.log(payload.uid);
            userManager.findUserById(payload.uid, function(doc){
                    console.log(doc);
                    resp.send(JSON.stringify(doc));
                });
            break;

        case 'JOIN_GAME':
            console.log('JOIN_GAME: ' + payload.uid);
            userManager.findUserById(payload.uid, function(doc) {
                console.log(doc);
                server.singleGameServer.emit('JOIN_GAME', doc);
            });
            break;

        case 'NEW_SCORE':
            console.log('new score:' + payload.score);
            singleGameManager.add(payload.userid,
                    payload.gamename,
                    payload.score,
                    payload.time,
                    function(record) {
                        userManager.findUserById(payload.userid, function(user) {
                            server.singleGameServer.emit('NEW_GAME_SCORE', {'user':user, 'record':record});
                            
                            console.log('send back new score');
                        });

                    });

            break;
        case 'GET_SCORE_LIST':
            singleGameManager.findRecords(payload.gamename,function(records){
                resp.send(JSON.stringify({
                    'gamename':payload.gamename, 
                    'records':records
                }));
            });
            break;
        case 'GET_RANK_LIST':
            rankManager.findRecords(payload.gamename,function(records){
                
                resp.send(JSON.stringify({
                    'gamename':payload.gamename, 
                    'records':records
                }));
            });
            break;
        case 'SCORE_RANK':
            singleGameManager.getScoreRank(payload.gamename, payload.score,function(rank){
                console.log(rank);
                var result={
                        'rank':rank
                };
                resp.send(JSON.stringify(result));
            });
            break;
    }   

},

};

server.start(54321);
