var rankManager = require('./touch2rank').getPlayerRankManager();

rankManager.init();
console.log('ok');
rankManager.deleteRank('4f155654fa40299545000034');