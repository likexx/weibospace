
exports.createGame=function() {
    return new touch2Game();
};

exports.getMaxNumber=function() {
    return 25;  
};

function touch2Game() {
    this.backgroundId=Math.floor(Math.random()*6);
    this.ballId = Math.floor(Math.random()*9);
    this.setId = 1;
    this.board={};
    /*
    this.player1={id:player1, score:0, ready:false};
    this.player2={id:player2, score:0, ready:false};
    */
    this.expectNumber = -1;
    this.expectValues = [];
    this.players = {};
    
    this.init = function() {
        this.reset();
    };
    
    this.gameReady = function() {
//        return this.player1.ready && this.player2.ready;  
        for(i in this.players){
            if (this.players[i].ready == false){
                return false;
            }
        }
        
        return true;
    };
    
    this.setPlayerReady = function(playerId){
      if (this.players[playerId]!= null && this.players[playerId]!=undefined){
          this.players[playerId].ready = true;
      }  
    };
    
    this.addPlayer = function(playerId){
        this.players[playerId]={
          id:playerId,
          score:0,
          ready:false
        };
    };
    
    this.removePlayer = function(playerId){
        if (this.players[playerId]!=null && this.players[playerId]!=undefined){
            delete this.players[playerId];
        }  
      };

    this.resetPlayers = function() {
        for(i in this.players){
            this.players[i].score = 0;
            this.players[i].ready = 0;
        }
    };
    
    
    this.getRandomArray = function(n) {
        var a = [];
        for(var i = 0;i<25;++i) {
            a.push(i);
        }
        
        for(i = 24; i>=0;i--) {
            var next = Math.floor(Math.random()*(i+1));
            var v = a[next];
            v = a[i];
            a[i]=a[next];
            a[next]=v;
        }
        
        return a;
  
    };
    
    this.getNextValue = function() {
      var value = -1;
      if (this.expectValues.length > 0) {
          value = this.expectValues[0] + 1;
          this.expectValues.splice(0, 1);
      }
      return value;
    };
    
    this.reset=function() {

        this.expectValues = this.getRandomArray(25);
        this.backgroundId=Math.floor(Math.random()*6);
        this.ballId = Math.floor(Math.random()*9);
        this.setId = Math.floor(Math.random()*5) + 1;
        this.board={};

        this.resetPlayers();
        
        this.expectNumber = this.getNextValue();
        
        var a = this.getRandomArray(25);
        
        for(i=0;i<25;++i) {
            this.board[a[i]] = (i+1);
        }
        
        
    };
    
    this.onUserClick=function(uid, index) {
        if (!this.gameReady()) {
            console.log('game not ready');
            return null;
        }
        
        var i = parseInt(index);

        var player = this.players[uid];
        if (player ==null && player==undefined){
            console.log('cannot find player');
            return null;
        }

        if (this.board[i] != null && 
            this.board[i] != undefined) {
            console.log(this.board[i] + " : " + this.expectNumber);

            if (this.board[i] == this.expectNumber) {
                // clicked at the right number
                var number = this.board[i];
                this.board[i] = null;
                /*
                if (uid == this.player1.id) {
                    this.player1.score+=1;
                } else {
                    this.player2.score+=1;
                }
                */
                player.score++;
                
                this.expectNumber = this.getNextValue();
                
                return {
                    expectNumber:this.expectNumber,
                    players:this.players
                };
                
            } else {
                // user clicked at the wrong number, deduct score
                /*
                if (uid == this.player1) {
                    this.player1.score--;
                } else {
                    this.player2.score--;
                }
                */
                player.score--;
                return {
                    players:this.players
                };
                
            }
        }
        
        return null;
        
    };
    
    this.getGameInfo=function() {
        return {
        'board':this.board,
        'bgid':this.backgroundId,
        'ballid': this.ballId,
        'setid': this.setId,
        'expectValue': this.expectNumber,
        'players':this.players
        };
  
    };
};