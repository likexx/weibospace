<?php
/**
 * you only need to include this file
 * please read example in example directory
 */
require_once 'config.inc.php';
require_once 'RESTClient.class.php';
require_once 'RenRenClient.class.php';
require_once 'RenRenOauth.class.php';
?>