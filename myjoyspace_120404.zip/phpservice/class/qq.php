<?php
require_once(dirname(__FILE__) . '/help.php');
require_once(dirname(__FILE__) . '/dao.php');

class QQ {
	
	const CLIENT_ID = '100239144';
	const CLIENT_SECRET = 'e66435845309bbfd98c17145677e3abd';
	
	
	public static function getQQCredential($code) {
		$my_url = "http://www.myjoyspace.com/phpservice/registeruser.php?type=qq";
		
		//create the final string to be posted using implode()
		$post_string = "grant_type=authorization_code&"
		. "client_id=" . self::CLIENT_ID . "&redirect_uri=" . urlencode($my_url)
		. "&client_secret=" . self::CLIENT_SECRET . "&code=" . $code;
		
		$result = HELP::get('https://graph.qq.com/oauth2.0/token',$post_string);
		///		$data = json_decode($result);
		$start = strpos($result, "=");
		$end = strrpos($result,"&");
		$token = substr($result, $start+1, $end - $start - 1);
		
		$result = HELP::post("https://graph.qq.com/oauth2.0/me", "access_token=" . $token);
		$start = strpos($result,'openid":"') + 9;
		$end=strrpos($result,'"}');
		$openid = substr($result, $start, $end - $start);
		
		return array(
		    'token'=>$token,
		    'openid'=>$openid
		);
	}
	
	public static function getUser($params) {
		$get_string = "access_token=" . $params['access_token'] . "&oauth_consumer_key=" . $params['appid'] . "&openid=" . $params['openid'];
		
		return HELP::get('https://graph.qq.com/user/get_user_info', $get_string);
	}
	
	public static function post($postData) {
        $postData['oauth_consumer_key'] = self::CLIENT_ID;
		return HELP::postData('https://graph.qq.com/share/add_share', $postData);
		
	}
	
	public static function registerUser($id, $token) {
		
		// check qq user existance
		$con = DAO::getConnection();
		
		$sql = "SELECT * FROM QQ_USER WHERE extid='$id'";

		$rows = mysql_query($sql, $con);
		
		$rowCount = mysql_num_rows($rows);
		$uid = 0;
		
		if ($rowCount < 1) {
			$username = "QQ_" . $id;

			// add to global user lookup table
			$sql = "INSERT INTO user (username) VALUES ('$username')";
			mysql_query($sql, $con);

			$rows = mysql_query("SELECT id from user where username='$username'", $con);
			$row = mysql_fetch_assoc($rows);
			$uid = $row['id'];
			
			// add to qq_user
			$sql = "INSERT INTO QQ_USER (userid, extid, token) VALUES ('$uid', '$id', '$token')";
			mysql_query($sql, $con);
		}
		
		mysql_close($con);
		
		
	}
	
}
?>
