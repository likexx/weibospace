<?php
require_once('./dao.php');
require_once('./help.php');

class UserWeibo {
	
	private $uid = 0;
	private $extId = null;
	private $token = null;
	
	public function __construct($uid) {
/*		
		$this->uid = $uid;
		
		$conn = DAO::getConnection();
		
		$result = mysql_query("select * from weibo_user where id='$uid'", $conn);
		
		$rowCount = mysql_num_rows($result);
		
		if ($rowCount > 0) {
			$row = mysql_fetch_assoc($result);
			
			$this->extId = $row['extid'];
			$this->token = $row['token'];
		}
*/		
	}
/*	
	public function publish($content) {
		$data = htmlentities(trim($content),ENT_QUOTES, "UTF-8");
		$data = urlencode($content);
		$result = HELP::postData('https://api.weibo.com/2/statuses/update.json',
				array(
				'access_token'=>$this->token,
				'status'=>$data));
		
		$postResult = json_decode($result);

		return postResult->error_code;
		
	}
*/	
}
?>
