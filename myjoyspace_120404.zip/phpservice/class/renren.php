<?php 
require_once './renren/requires.php';

class Renren {

	const app_key = "501fa04d686d4bd99cb45aeaf8f73aa7";
	const app_secret = "aeaa141e2eae461eac9a1ac6871daf80";
	
	
	public static function getUser($code) {
		$my_url = "http://www.myjoyspace.com/phpservice/registeruser.php?type=renren";
		
		$post_string = "grant_type=authorization_code&"
		. "client_id=" . self::app_key . "&redirect_uri=" . urlencode($my_url)
		. "&client_secret=" . self::app_secret . "&code=" . $code;
		
		$result = HELP::post('https://graph.renren.com/oauth/token',$post_string);
		
		$data = json_decode($result);
		
		$access_token = $data->access_token;
		
		$oauth = new RenRenOauth();
		
		$key = $oauth->getSessionKey($access_token);

		$session_key = $key['renren_token']['session_key'];
		
		$client = new RenRenClient();
		
		$client->setSessionKey($session_key);


		
		$users = $client->POST('users.getInfo', array());

		$user = $users[0];
		
		return array(
		    'user'=>$user,
		    'token'=>$access_token
		);
	}
	
	public static function post($message, $access_token) {
        
        $oauth = new RenRenOauth();
        
        $key = $oauth->getSessionKey($access_token);

        $session_key = $key['renren_token']['session_key'];
        
        $client = new RenRenClient();
        
        $client->setSessionKey($session_key);
        
        $result = $client->POST('share.share', array(
            'type'=>6,
            'url'=>'http://www.myjoyspace.com?time=' . rand()
        ));

	}
}

?>