<?php 
$uid = 0;

if (isset($_COOKIE['uid'])) {
   $uid = $_COOKIE['uid'];
} 
if ($uid == 0) {
	return;
}
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

<link rel="stylesheet" href="./main.css" type="text/css" />
<link rel="stylesheet" href="./css/ui-darkness/jquery-ui-1.8.16.custom.css" type="text/css" />
<script type="text/javascript" src="./js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="./js/jquery-ui-1.8.16.custom.min.js"></script>
<script type="text/javascript" src="./js/yahoo-min.js"></script>
<script type="text/javascript" src="./js/json-min.js"></script>
<script type="text/javascript" src="./js/app.js"></script>

<script>
function publish() {
    var weibo_checked = $("#weibo_cb").prop("checked");
    var qq_checked = $("#qq_cb").prop("checked");
    var renren_checked = $("#renren_cb").prop("checked");
    var fb_checked = $("#fb_cb").prop("checked");

    var content = {
		      content: $('#publish_content').val()
	};

	if(weibo_checked) {
		$.post('./phpservice/publish_weibo.php', 
				content,
				function(data) {
			        alert(data);
			/*
					if (data!='ok') {
						var next = qq_checked?'qq,':'' + renren_checked?'renren,':'' + fb_checked?'fb':'';
					    window.location.href="https://api.weibo.com/oauth2/authorize?client_id=387605663&response_type=code&redirect_uri=" + 
					                         escape("http://www.myjoyspace.com/phpservice/publish_weibo.php?next=" + next);
                    }
                    */
				});
	} else if (qq_checked) {
		$.post('./phpservice/publish_qq.php', 
				content,
				function(data) {
					if (data!='ok') {
						var next = renren_checked?'renren,':'' + fb_checked?'fb':'';
					    window.location.href="https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=100239144&redirect_uri=" +
					                         escape("http://www.myjoyspace.com/phpservice/publish_qq.php?next=" + next) +
					                         "&scope=get_user_info,add_share";
                    }
				});
	} else if (renren_checked) {
		$.post('./phpservice/publish_renren.php', 
				content,
				function(data) {
					if (data!='ok') {
						var next = fb_checked?'fb':'';
					    window.location.href="https://graph.renren.com/oauth/authorize?client_id=175249&response_type=code&redirect_uri=" + 
					                         escape("http://www.myjoyspace.com/phpservice/publish_renren.php?next=" + next) +
					                         "&display=page&scope=status_update,publish_share";
                    }
				});
	} else if (fb_checked) {
		$.post('./phpservice/publish_facebook.php', 
				content,
				function(data) {
					if (data!='ok') {
					    window.location.href="https://www.facebook.com/dialog/oauth?client_id=214122235315121&redirect_uri=" + 
					                         escape("http://www.myjoyspace.com/phpservice/publish_facebook.php") + 
					                         "&scope=email,read_stream,status_update,publish_stream,offline_access";
                    }
				});
	}
	
}


</script>

</head>

<body>

      <div style="float:left;width:40%;border-radius:9px;background-color:#CCC;">
      <textarea id="publish_content" rows="5" cols="50"></textarea><br/>
      <input type="checkbox" id="weibo_cb"/>新浪微博
      <input type="checkbox" id="qq_cb"/>QQ空间
      <input type="checkbox" id="renren_cb"/>人人
      <input type="checkbox" id="fb_cb"/>facebook
      <br/>
      <input type="button" value="发布" onclick="publish();"/><br/>
      
      </div>


</body>
</html>