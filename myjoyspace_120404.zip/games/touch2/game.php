<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
	<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<link rel="stylesheet" href="../../css/ui-darkness/jquery-ui-1.8.16.custom.css" type="text/css" />
<script type="text/javascript" src="../../js/yahoo-min.js"></script>
<script type="text/javascript" src="../../js/json-min.js"></script>
<script type="text/javascript" src="../../js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="../../js/jquery-ui-1.8.16.custom.min.js"></script>
<script src="http://106.187.43.45:54321/socket.io/socket.io.js"></script>
<script type="text/javascript" src="./touch2.js"></script>

<style type="text/css"> 
    .ui-dialog .ui-dialog-buttonpane  {text-align:center;}
    .ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset {float:none;}
</style> 

</head>

<body id="body" onload="init();" style='font-family:"Microsoft YaHei",Arial;text-align:center;background: black url("./background/background0.jpg") no-repeat;'>

<div  style='position:absolute;left:200px;top:55px;font-size:22px;color:#80FF00;'>
点击<span id='next_value'></span>
</div>
	
<div id="canvas" style="position:absolute;left:50px; top: 100px; width:400px;height:400px;font-size:30px;" onselectstart='return false;';>
</div>

<div id="score_list" style="position:absolute;left:550px; top: 100px; width:250px;height:100px;font-size:12px;text-align:left;color:white;font-size:16px;" onselectstart='return false;';>
等待其它玩家加入...
</div>

<div id="chat_div" style="position:absolute;left:550px; top: 250px; width:250px;height:300px;font-size:12px;text-align:left;color:white;font-size:16px;" onselectstart='return false;';>
<hr>
<div id="chat_messages" style='width:250px; height:200px;'>
</div>
<textarea id="chat_input_message" cols="20" rows="3"></textarea><br/>
<input type='button' value='送出' onclick='sendChatMessage();'>
</div>


<div id='time_count' style='position:absolute;top:10px;left:200px;font-size:25px;color:white;'></div>
               
<!--                 
<div id='music' style='visibility:hidden;'>
     <embed src="./music/pre.mid" />
     <bgsound loop="0" src="./music/pre.mid">
</div>
 -->
 
<!-- for preloading purpose -->
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background0.jpg');width:800px; height:600px;">
</div>
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background1.jpg');width:800px; height:600px;">
</div>
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background2.jpg');width:800px; height:600px;">
</div>
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background3.jpg');width:800px; height:600px;">
</div>
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background4.jpg');width:800px; height:600px;">
</div>
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background5.jpg');width:800px; height:600px;">
</div>

</body>

</html>
