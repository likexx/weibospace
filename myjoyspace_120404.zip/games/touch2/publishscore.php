<?php 
require_once('../../phpservice/class/node.php');

if (!isset($_POST['score'])){
   return;
}

$uid = $_COOKIE['uid'];

$node= new Node();

$payload=array(
    'userid'=>$uid,
    'gamename'=>$_POST['gamename'],
    'score'=>$_POST['score']
);

$node->dataPush($uid, 'NEW_SCORE',$payload);

?>