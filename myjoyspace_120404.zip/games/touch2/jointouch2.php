<?php 
require_once('../../phpservice/class/node.php');

$uid = $_COOKIE['uid'];

$node= new Node();

$payload=array(
    'uid'=>$uid
);

$data = $node->dataPush($uid, 'JOIN_TOUCH2',$payload);

echo json_encode($data);

?>