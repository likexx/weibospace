<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
	<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<link rel="stylesheet" href="../../css/ui-darkness/jquery-ui-1.8.16.custom.css" type="text/css" />
<script type="text/javascript" src="../../js/yahoo-min.js"></script>
<script type="text/javascript" src="../../js/json-min.js"></script>
<script type="text/javascript" src="../../js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="../../js/jquery-ui-1.8.16.custom.min.js"></script>
<script src="http://106.187.43.45:54321/socket.io/socket.io.js"></script>
<script type="text/javascript" src="./touch2.js"></script>
<script type="text/javascript" src="./singlegame.js"></script>

<style type="text/css"> 
    .ui-dialog .ui-dialog-buttonpane  {text-align:center;}
    .ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset {float:none;}
</style> 

</head>
<body id="body" onload="init();" style='font-family:"Microsoft YaHei",Arial;background-color:black;'>

<div id="LOADING_DIV" style="color:white;font-size:30px;">
与游戏服务器连接中，请稍候...<br/>
使用Chrome/Firefox以获得更快连接速度
</div>

<div id='GAME_ROOM_DIV' style='width:800px;visibility:hidden;'>

<div id="new_room_div" style='position:absolute;left:10px;top:55px;font-size:22px;color:#80FF00;background-color:black;'>
<input id='new_game_room_id' size=20 maxlength=20 value='请输入游戏房间名字' onfocus="this.value='';this.style.color='black';" style='color:#AAA'></input>
<input type="button" value="建立游戏" onclick='GameClient.createNewGame();'></input><br/>
<span style='font-size:14px;'>游戏房间名将作为你建立的游戏的唯一标识，其它玩家可在列表看到该房间并加入。房间名必须是不超过20个的数字、英文大小写字母的组合</span>
<hr/>
</div>

<div id='room_list' style='position:absolute;left:10px;top:150px;font-size:16px;color:white;background-color:black;'>
</div>

</div>

<div id='GAME_CANVAS_DIV' style='position:absolute;left:-10000px;top:-10000px;font-size:16px;color:white;'>

    <div  style='position:relative;left:50px;top:40px;font-size:22px;color:#80FF00;'>
    点击对应图片<span id='expect_value'>12</span>
    </div>
    <br/>
    <br/>

    <div id="canvas" style="position:relative;left:50px; width:400px;height:400px;font-size:30px;" onselectstart='return false;';>
    </div>
    
    <div style="position:absolute;left:550px; top: 20px; width:250px;height:100px;cursor:pointer;">
    <input type='button' value='退出' onclick="exitGame();">
    </div>
    
    <div id="score_list" style="position:absolute;left:550px; top: 60px; width:250px;height:250px;font-size:12px;text-align:left;color:white;overflow:auto;" onselectstart='return false;';>
    等待其它玩家加入...
    </div>
    
    <div id="chat_div" style="position:absolute;left:550px; top: 320px; width:250px;height:250px;font-size:12px;text-align:left;color:white;" onselectstart='return false;';>
    
        <hr>
        
        <div id="chat_messages" style='width:250px; height:150px; overflow:auto;'>
        </div>
        <br/>
        <textarea id="chat_input_message" cols="20" rows="3"></textarea><br/>
        <input type='button' value='送出' onclick='sendChatMessage();'>
    
    </div>

</div>

<div id="SINGLE_GAME_DIV" style="position:absolute:top:-10000px;left:-10000px;visibility:hidden;">

<table><tr>
<td style="width:50px;"></td>
<td style="width:200px;vertical-align:top;">
    <div id='time_count' style='font-size:25px;color:white;'></div>
</td>
<td style="vertical-align:top;">
    <div  style='font-size:22px;color:#80FF00;'>
    点击对应图片<br/><div id='single_expect_value'><img id="click_image_target" width="80px" height="80px"/></div>
    </div>
</td>
</tr></table>

<table>
<tr><td>    
<div id="single_canvas" style="position:relative;left:50px; width:400px;height:400px;font-size:30px;" onselectstart='return false;';>
</div>
</td>
<td>
<div style="position:relative; left:100px; width:250px;">
<input type='button' value='退出' onclick="exitGame();">
</div>

<div id="single_messages" style="position:relative; left:100px; width:250px;height:400px;font-size:12px;text-align:left;color:white;" onselectstart='return false;';>
</div>
</td>
</tr></table>

</div>

<!-- for preloading purpose -->
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background0.jpg');width:800px; height:600px;">
</div>
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background1.jpg');width:800px; height:600px;">
</div>
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background2.jpg');width:800px; height:600px;">
</div>
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background3.jpg');width:800px; height:600px;">
</div>
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background4.jpg');width:800px; height:600px;">
</div>
<div style="position:absolute; top:-10000px; left: -10000px;background-image:url('./background/background5.jpg');width:800px; height:600px;">
</div>

<script>

for (var i=1;i<=5;++i) {
    for(var j=1;j<=25;++j) {
        document.write('<div style="position:absolute;top:-10000px;left:-10000px;"><img src="./set' + i + '/' + j + '.jpg"/></div>');
    }
}

</script>


</body>

</html>
