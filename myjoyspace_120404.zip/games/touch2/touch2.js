WEB_SOCKET_SWF_LOCATION = "WebSocketMain.swf";
// Set this to dump debug message from Flash to console.log:
WEB_SOCKET_DEBUG = true;

var StartGameCount = 4;
var canvas = null;
var timeCountDiv = null;
var gameStarted = false;
var clicked = {};


var battleMusic = [ './music/battle1.mid', './music/battle2.mid',
        './music/battle3.mid' ];
var victoryMusic = './music/win.mid';

var gameState = {
        room_id:0,
        uid:0,
        isPlayer1:false
};

var UserCache={};

var CurrentUser = {
  uid: null,
  username:null,
  image: null
};

var playerScores={};
var winner = {
  id:-1,
  score:-99999
};

var GameClient = {
        socket: null,
        callbacks:{},
        currentSet: 1,
        connected: false,
        
        init:function() {
            this.socket = io.connect('http://106.187.43.45:54321/touch2');
            
            this.callbacks['UPDATE_ROOMS'] = this.onUpdateRooms;
            this.callbacks['START_GAME'] = this.onStartGame;
            this.callbacks['USER_JOIN'] = this.onUserJoin;
            this.callbacks['REMOVE_NUMBER'] = this.onRemoveNumber;    
            this.callbacks['UPDATE_SCORE'] = this.onUpdateScore;    
            this.callbacks['CHAT_MESSAGE'] = this.onChatMessage;    
//            this.callbacks['LEAVE_ROOM'] = this.onLeaveRoom;    
            this.callbacks['UPDATE_ROOM_INFO'] = this.onUpdateRoomInfo;    
            
            this.socket.on('CONNECTED', function(data){
                GameClient.connected = true;
                $('#LOADING_DIV').remove();
                $('#GAME_ROOM_DIV').css('visibility','visible');
                GameClient.loadRooms();
            });

            
            this.socket.on('WAIT_PLAYER', function(data){
                gameState.room_id = data.roomId;
//                UI.initGameCanvas();
                UI.initSingleGame();
                SingleGame.init();
            });
            
            
            this.socket.on('message', function(msg) {  

                var d = YAHOO.lang.JSON.parse(msg);
                var cmd = d.cmd;
                if (GameClient.callbacks[cmd]!=undefined && GameClient.callbacks[cmd] != null) {
                    GameClient.callbacks[cmd](d);
                }

            });
            

        },
            
        validateRoomId: function(roomId) {
            var invalidLetters=['<','>','/','\\', '"','&','[',']'];
            for(i in invalidLetters){
                var c = invalidLetters[i];
                if (roomId.indexOf(c)>=0){
                    return false;
                }
            }
            
            return true;
        },
        
        createNewGame:function() {
            if (CurrentUser.uid==null) {
                return;
            }
            var roomId=$('#new_game_room_id').val();
            if (!GameClient.validateRoomId(roomId)) {
                return;
            }   
            
            this.socket.emit('CREATE_NEW_ROOM', {'uid':CurrentUser.uid, 'roomId': roomId});
        },
        
        loadRooms:function() {
            GameClient.socket.emit('GET_ROOMS',{});
        },
        
        onUpdateRooms: function(d) {
            UI.showRooms(d.rooms);
        },
        
        joinRoom:function(roomid) {
            this.socket.emit('JOIN_ROOM',{
                'roomId':roomid,
                'uid':CurrentUser.uid
            });
            
        },
        
        /*
        onLeaveRoom:function(d) {
            UI.initRoomList();
            GameClient.socket.emit('LEAVE_ROOM',{'roomId':gameState.room_id});
//            GameClient.loadRooms();
        },
        */
        
        onUpdateRoomInfo:function(d) {
            var room = d.room;
            var players = room.players;
            
            var len = 0;
            for(i in players) {
                len++;
            }
            if (len == 1) {
                var div = $('<div id="SINGLE_MODE_DIALOG">');
                var content = "现在只有你一个玩家，进入单人游戏模式";
                div.css({
                    'width':320,
                    'height':240
                }).html(content).appendTo('body').dialog({
                        show: "explode",
                        hide: "explode",
                        width: 360,
                        height: 260,
                        position: [200,120],
                        title: "单人游戏模式",
                        
                        close: function(event, ui) {
//                            setMusic(battleMusic[Math.floor(Math.random() * 3)]);
                            UI.initSingleGame();
                            SingleGame.init();
                        },
                        
                        buttons: [
                                  {
                                      text: "开始",
                                      click: function() { $(this).dialog("close"); }
                                  },

                              ]
                });
                
            } else {
                UI.buildPlayerScoreList(players);
            }
            
        },
         
        
        onStartGame:function(data) {
            SingleGame.stopped = true;
            UI.initGameCanvas();
            var d = data.data;
            gameState.room_id = d.room_id;
            GameClient.currentSet = d.setid;
            winner.id = -1;
            winner.score = -99999;
            UI.setupCanvas(d.bgid, d.ballid);
            UI.setBoard(d.board);
            
            UI.buildPlayerScoreList(d.players);
            
            $('#expect_value').html(getTarget(d.expectValue));
        },
        

        onUserJoin:function(data) {
            gameState.room_id = data.roomId;
            var userid = data.userid;
            var user = UserCache[userid];
            if ( user != null && user!=undefined) {
                UI.showUserJoinDialog(user);
                return;
            }
            
            $.post('/getuser.php', {uid:userid}, function(data){
                var user=YAHOO.lang.JSON.parse(data);
                UserCache[user._id]=user;
                UI.showUserJoinDialog(user);
            });
            
        },
        
        onRemoveNumber:function(d) {
            var block = $('#block_' + d.index);
            block[0].style.backgroundImage = "";
            block[0].innerHTML = '<img src="./Explosion.gif" width="80px" onselectstart="return false;"/>';
            setTimeout('UI.removeExplosion("' + block[0].id + '");', 800);

            if (d.expectValue < 0) {
                stopGame();
            } else {
                $('#expect_value').html(getTarget(d.expectValue));
            }

            UI.updateScore(d.players);

  /*            
            $('#player1_score').html(d.score1);
            $('#player2_score').html(d.score2);
*/
        },

        onUpdateScore:function(d) {
            UI.updateScore(d.players);
        },
        
        onChatMessage:function(data) {
            var user = data.user;
            var message = data.message;
            
            var prevContent = $('#chat_messages').html();

            var content = "<div>" +
            "<table><tr><td><img src='" + user.image + "' width='32px' height='32px'/></td><td>" +
            message +
            "</td></table></div>" + prevContent;
            
            $('#chat_messages').html(content);

        }

};


var UI={
  showRooms:function(rooms) {
      var content = "<table>";
      var len = rooms.length;
      for(var i=0;i<len;++i) {
          if (i%4==0) {
              content+="<tr>";
          }
          
          var room = rooms[i];
/*          
          var player1=room.player1;
          var p1 = null;
          var p2 = null;
          
          if (UserCache[player1]==null || UserCache[player1]==undefined) {
              $.post('/getuser.php', {uid:player1}, function(data){
                  var user=YAHOO.lang.JSON.parse(data);
                  UserCache[user._id]=user;
                  UI.showRooms(rooms);
              });
          } else {
              p1 = UserCache[player1];
          }

          var player2=room.player2;
          
          if (player2 != null && 
              (UserCache[player1]==null || UserCache[player1]==undefined)) {
              $.post('/getuser.php', {uid:player2}, function(data){
                  var user=YAHOO.lang.JSON.parse(data);
                  UserCache[user._id]=user;
                  UI.showRooms(rooms);
              });
          } else {
              p2 = UserCache[player2];
          }

          content+="<td style='width:200px;height:100px;'><div id='room_" + room.id + "' style='cursor:pointer;' onclick='GameClient.joinRoom(\"" + room.id + "\");'>" + room.id + '<br/>' +
                   ((room.player1 != null && room.player2!=null) ? "[<span style='color:red;font-size:11px;'>比赛进行中</span>]" : "[<span style='font-size:11px;'>等待加入</span>]") + '<br/>' +
                   "<span style='font-size:12px;'>" + (p1 !=null ? p1.username : "") + (p2!=null? (" v.s. " + p2.username):"") + "</span>" +
                   "</div></td>";
*/          
          content+="<td style='width:200px;height:100px;'><div id='room_" + room.id + "' style='cursor:pointer;' onmouseover='this.style.color=\"green\";' onmouseout='this.style.color=\"\";' onclick='GameClient.joinRoom(\"" + room.id + "\");'>" + room.id + "<br/>点击加入游戏</div></td>";

          
          if ((i+1)%4==0) {
              content+="</tr>";
          }
      }
      $('#room_list').html(content);
  },

  showUserJoinDialog:function(user) {
      var div = $('<div id="ROOM_READY_DIALOG">');
      var content = "<img src='" + user.image + "'>" + user.username + "加入</br>" +
                    "现在进入多人模式，你需要和对手同时点击数字，比赛谁动作更快，消除数字最多的获胜。注意，如果点错数字将被扣分！";
      
      div.css({
          'width':320,
          'height':240
      }).html(content).appendTo('body').dialog({
              show: "explode",
              hide: "explode",
              width: 360,
              height: 260,
              position: [200,120],
              title: "有新对手加入",
              
              close: function(event, ui) {
//                  setMusic(battleMusic[Math.floor(Math.random() * 3)]);
                  setTimeout('restartGame();', 500);
              },
              
              buttons: [
                        {
                            text: "开始对战",
                            click: function() { $(this).dialog("close"); }
                        },

                    ]
      });
  
  },
  
  buildPlayerScoreList:function(players) {

      var content = "<table><tr><td colspan='2'>比赛玩家</td><td>分数</td></tr>";
      for(i in players) {
          var player = players[i];
          content += "<tr><td><img id='player_"  + 
                     player.id + 
                     "_img'/></td><td><span id='player_" + 
                     player.id + 
                     "_name'></span></td><td><span id='player_" + 
                     player.id + 
                     "_score'></span></td></tr>";
          
      };
      
      content+="</table>";

      $('#score_list').html(content); 
      
      for(i in players) {
          var player = players[i];
          
          var user = UserCache[player.id];
          if (user !=null && user!=undefined) {
              UI.showPlayerScoreListInfo(user);
          } else {
              $.post('/getuser.php',{uid:player.id}, function(data) {
                  var user=YAHOO.lang.JSON.parse(data);
                  UserCache[user._id] = user;
                  UI.showPlayerScoreListInfo(user);
              });
              
          }
          
      };
      
      UI.updateScore(players);

  },
  
  showPlayerScoreListInfo:function(user){
      
      var prefix = "player_" + user._id;
      $('#' + prefix + '_img').attr('src', user.image);
      $('#' + prefix + '_name').html(user.username);
      
  },

  updateScore:function(players) {
      for (i in players) {
          var player = players[i];
          $('#player_' + player.id + '_score').html(player.score);
          if (player.score>winner.score) {
              winner.score = player.score;
              winner.id = player.id;
          }
      }
      
  },
  
  initSingleGame:function() {
      $('#GAME_ROOM_DIV').css({
          'position': 'absolute',
          'top':-10000,
          'left':-10000
          });
      
      $('#SINGLE_GAME_DIV').css({
          'position': 'absolute',
          'top':0,
          'left':0,
          'visibility':'visible'
          });

      $('#GAME_CANVAS_DIV').css({
          'position': 'absolute',
          'top':-10000,
          'left':-10000,
          });
      

      $('body').css('background','black url("./background/background0.jpg") no-repeat');
      
  },
  
  initGameCanvas:function(){
   $('#GAME_ROOM_DIV').css({
       'position': 'absolute',
       'top':-10000,
       'left':-10000
       });

   $('#SINGLE_GAME_DIV').css({
       'position': 'absolute',
       'top':-10000,
       'left':-10000,
       });

   
   $('#GAME_CANVAS_DIV').css({
       'position': 'absolute',
       'top':0,
       'left':0,
       });
   
   $('body').css('background','black url("./background/background0.jpg") no-repeat');
  },
  
  initRoomList:function() {
      $('#canvas').html('');
      $('#score_list').html('');
      $('#chat_messages').html('');
      $('#chat_input_message').val('');
      
      $('#GAME_ROOM_DIV').css({
          'position': 'absolute',
          'top':0,
          'left':0
          });
      
      $('#GAME_CANVAS_DIV').css({
          'position': 'absolute',
          'top':-10000,
          'left':-10000
          });

      $('#SINGLE_GAME_DIV').css({
          'position': 'absolute',
          'top':-10000,
          'left':-10000,
          'visibility':'hidden'
          });

      $('body').css('background','black');
  
  },
  
  setBoard:function(board){

      for ( var i = 0; i < 5; ++i) {
          for ( var j = 0; j < 5; ++j) {
              var id = (i * 5) + j;
              var div = document.getElementById('block_' + id);
              div.innerHTML = getTarget(board[id]);
              div.style.cursor = 'crosshair';
              div.onmousedown = onClickAtNumber;
              div.onselectstart = function() {
                  return false;
              };
          }
      }

  },
  
  setupCanvas:function(backgroundId, ballId) {

      timeCountDiv = document.getElementById('time_count');
      canvas = document.getElementById('canvas');

      var bgUrl = './background/background' + backgroundId + ".jpg";
      
      $('#body').css('background-image','url("' + bgUrl + '")').attr("onselectstart","return false;");

 //     var imgUrl = 'ball'+ ballId + '.png';

      for ( var i = 0; i < 5; ++i) {
          for ( var j = 0; j < 5; ++j) {
              var id = i * 5 + j
              var div = document.getElementById("block_" + id);
              if (div == null || div == undefined) {
                  div = document.createElement('div');
                  div.id = 'block_' + id;
              }
              div.style.position = 'absolute';
              div.style.width = '80px';
              div.style.height = '80px';
              div.style.top = i * 80 + 'px';
              div.style.left = j * 80 + 'px';
              div.style.visibility = "visible";

//              div.style.backgroundImage = 'url("' + imgUrl + '")';
//              div.style.backgroundRepeat = "no-repeat";

              div.style.color = 'black';
              div.style.fontWeight = 'bold';
              div.style.fontSize = '36px';
              div.style.textAlign = 'center';

              canvas.appendChild(div);
          }
      }

  },
  
  removeExplosion:function(id) {
      $('#' + id).css('visibility','hidden');
  }

  
};


function exitGame() {
    GameClient.socket.emit('EXIT_GAME',{'roomId':gameState.room_id});
    UI.initRoomList();
}


function publishScore(score) {
    $.post('./publishscore.php',{'score':score});
    
}

function showGameMessage(data) {
    var content = $('#messages').html();
    content = data+ '<br/>' + content;
    $('#messages').html(content);
}


function stopGame() {
    for ( var i = 0; i < 5; ++i) {
        for ( var j = 0; j < 5; ++j) {
            var id = (i * 5) + j;
            var div = document.getElementById('block_' + id);

            canvas.removeChild(div);
        }
    }

    setMusic(victoryMusic);

    var user = UserCache[winner.id];

    var content = "<div style='color:white;'>冠军:" + "<img src='" + user.image + "'/>" + user.username + "<br/></div>";

    
    var offset = $('#canvas').offset();

    var div = $('<div id="SCORE_DIALOG">');
    
    div.css({
        'width':320,
        'height':240
    }).html(content).appendTo('body').dialog({
            show: "explode",
            hide: "explode",
            width: 360,
            height: 260,
            position: [offset.left+50,offset.top+20],
            title: "游戏结果",
            
            close: function(event, ui) {
//                setMusic(battleMusic[Math.floor(Math.random() * 3)]);
                setTimeout('restartGame();', 500);
            },
            
            buttons: [
                      {
                          text: "继续",
                          click: function() { $(this).dialog("close"); }
                      }

                  ]
    });
}

function restartGame() {
    GameClient.socket.emit('RESTART_GAME', {'room_id': gameState.room_id, 'uid':CurrentUser.uid});
    
}

function htmlEncode(str) {
    
    return String(str)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
}

function sendChatMessage() {
    var data = $('#chat_input_message').val();
    data = htmlEncode(data);
    
    var message = {uid:CurrentUser.uid, room_id:gameState.room_id, value: data};

    GameClient.socket.emit('CHAT_MESSAGE', message);
    $('#chat_input_message').val("");
    
}

function onClickAtNumber() {
    var value = parseInt(this.id.replace('block_',''));
    
    GameClient.socket.emit('USER_CLICK', {'room_id': gameState.room_id, 'uid':CurrentUser.uid, 'index':value});

}

function getTarget(value) {
/*
    div.innerHTML = '<div style="position:relative;top:12px;" onselectstart="return false;">'
            + value + '</div>';
*/
    if (GameClient.currentSet>0) {
        return '<img src="./set' + GameClient.currentSet + '/' + value + '.jpg" width="80px" height="80px"/>';
    } else {
        return '<div style="position:relative;top:12px;" onselectstart="return false;">'
               + value + '</div>';
    }
}

function checkSocketConnection() {
    
}

function init() {
    
    GameClient.init();

    $('#chat_input_message').val();
    
    $('#chat_input_message').keypress(function(e) {
        if (e.keyCode == 13){
            sendChatMessage();
        }
    });
    
    $.post('/getuser.php',{}, function(data) {
        var user=YAHOO.lang.JSON.parse(data);
        CurrentUser.uid = user._id;
        CurrentUser.username = user.username;
        CurrentUser.image = user.image;
    });
    
//    initSocket();
}



function setMusic(filename) {
    /*
    var music = document.getElementById('music');
    var parent = music.parentNode;

    parent.removeChild(music);

    music.innerHTML = '<embed src="' + filename + '" />'
            + '<bgsound loop="0" src="' + filename + '">';
    parent.appendChild(music);
    */
    
}