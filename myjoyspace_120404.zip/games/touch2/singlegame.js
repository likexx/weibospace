WEB_SOCKET_SWF_LOCATION = "WebSocketMain.swf";
// Set this to dump debug message from Flash to console.log:
WEB_SOCKET_DEBUG = true;

var SingleGame = {

StartGameCount : 4,
canvas : null,
timeCountDiv : null,
gameStarted : false,
expectedValue : -1,
stopped: false,
startTime : 0,
expectValues:[],
imageSet: 1,

battleMusic : [ './music/battle1.mid', './music/battle2.mid', './music/battle3.mid' ],
victoryMusic : './music/win.mid',

socket : null,

initSocket:function() {
    SingleGame.socket = io.connect('http://106.187.43.45:54321/singleplayer');
    
    SingleGame.socket.on('CONNECTED', function(data){
//        $.post('./jointouchnumber.php',{});
    });
    
    /*
    SingleGame.socket.on('JOIN_GAME', function (data) {
        console.log(data);
        var content = "<img src='" + data.image + "'/>" +data.username + " 加入游戏";
        SingleGame.showGameMessage(content);
      });       
    */
    
    SingleGame.socket.on('NEW_GAME_SCORE', function (data) {
        var content = "<img src='" + data.user.image + "'/>" +data.user.username + " 游戏时间 " + data.record.score + "秒";

        SingleGame.showGameMessage(content);
      });       
    
},

publishScore:function(score) {
    $.post('./publishscore.php',{'gamename':'touchnumber','score':score});
},

showGameMessage:function(data) {
    var content = $('#single_messages').html();
    content = data+ '<br/>' + content;
    $('#single_messages').html(content);
},

getRandomArray:function(n) {
    var arr = [];
    for ( var i = 0; i < n; ++i) {
        arr.push(i + 1);
    }

    for ( var i = n - 1; i > 0; --i) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    return arr;

},

getRandomNumber:function() {
    return Math.random() * 100000;
},


stopGame:function() {
    for ( var i = 0; i < 5; ++i) {
        for ( var j = 0; j < 5; ++j) {
            var id = (i * 5) + j;
            var div = document.getElementById('block_' + id);

            SingleGame.canvas.removeChild(div);
        }
    }
    SingleGame.setMusic(victoryMusic);

//    document.getElementById('single_expect_value').innerHTML = '';
    SingleGame.gameStarted = false;
    SingleGame.StartGameCount = 4;

    var currentTime = new Date();
    var timeScore = (currentTime.getTime() - SingleGame.startTime.getTime()) / 1000.0;

    SingleGame.publishScore(timeScore);

    var content = "<div style='color:white;'>游戏时间: " + timeScore + "秒<br/></div>";
    
    var offset = $('#single_canvas').offset();
    
    var div = $('<div id="SCORE_DIALOG">');
    
    div.css({
        'width':320,
        'height':240
    }).html(content).appendTo('body').dialog({
            show: "explode",
            hide: "explode",
            width: 360,
            height: 260,
            position: [offset.left+50,offset.top+20],
            title: "游戏成绩",
            
            close: function(event, ui) {
                SingleGame.setMusic(battleMusic[Math.floor(Math.random() * 3)]);
                setTimeout('SingleGame.init();', 500);
            },
            
            buttons: [
                      {
                          text: "重新开始",
                          click: function() { $(this).dialog("close"); }
                      },
                      {
                          id:"publish_score",
                          text: "发布战绩",
                          click: function() {
                                 SingleGame.shareGameScore(timeScore);
                                 $("#publish_score").remove();
                          }
                      }
                  ]
    });
},

shareGameScore:function(score){

    $.post('/phpservice/getscorerank.php',
            {'gamename':'touchnumber',
             'score':score
            }, function(data){
                var rank=data;
                var title = CurrentUser.username + '刚刚完成点点看游戏, 成绩' + score + '秒, 世界排名:' + rank;
                var summary = '点点看是[游乐地带]休闲游戏竞赛中最简单的一种，考验你的眼力和反应力，你能获得更好成绩吗？';
                $.post('/phpservice/qqpost.php',{title:title, summary:summary}, function(data){
                });
                
            });
},

removeExplosion:function(id) {
    $('#' + id).css('visibility','hidden');
},

onClickAtNumber:function() {
    var value = this.value;

    if (value != SingleGame.expectedValue) {
        return;
    }

    this.style.backgroundImage = "";
    this.innerHTML = '<img src="./Explosion.gif" width="80px" onselectstart="return false;"/>';
    setTimeout('SingleGame.removeExplosion("' + this.id + '");', 800);

    SingleGame.expectedValue = SingleGame.getNextValue();
    if (SingleGame.expectedValue < 0) {
        SingleGame.stopGame();
    } else {
        SingleGame.setImage('target', SingleGame.expectedValue);
    }
},

getNextValue:function() {
    var value = -1;
    if (SingleGame.expectValues.length > 0) {
        value = SingleGame.expectValues[0];
        SingleGame.expectValues.splice(0, 1);
    }
    return value;
},

setOpacity:function(e, value) {
    e.style.opacity = value / 100;
    e.style.filter = 'alpha(opacity=' + value + ')';
},

updateTimeCount:function() {
    if (this.stopped) {
        return;
    }
    
    if (!SingleGame.gameStarted) {
        SingleGame.timeCountDiv.innerHTML = "";
        return;
    }
    var currentTime = new Date();
    var timeScore = (currentTime.getTime() - SingleGame.startTime.getTime()) / 1000.0;
    SingleGame.timeCountDiv.innerHTML = '时间: ' + timeScore;
    setTimeout('SingleGame.updateTimeCount();', 100);
},

setImage:function(id, value) {
    var image = './set' + SingleGame.imageSet + '/' + value + '.jpg';
    $('#click_image_' + id).attr('src', image);
},

setNumbers:function() {
    if (this.stopped) {
        return;
    }

    var randomNumbers = SingleGame.getRandomArray(25);

    for ( var i = 0; i < 5; ++i) {
        for ( var j = 0; j < 5; ++j) {
            var id = (i * 5) + j;
            var div = document.getElementById('block_' + id);
            div.value = randomNumbers[id];
            SingleGame.setImage(div.id, div.value);
            div.style.cursor = 'crosshair';
            div.onmousedown = SingleGame.onClickAtNumber;
            div.onselectstart = function() {
                return false;
            };
        }
    }
    SingleGame.setImage('target', SingleGame.expectedValue);
    setTimeout('SingleGame.updateTimeCount();', 100);
},

gameReady:function() {
    SingleGame.gameStarted = true;
    SingleGame.expectedValue = SingleGame.getNextValue();
    SingleGame.setImage('target', SingleGame.expectedValue);
},

gameStartCountDown:function() {
    if (this.stopped) {
        return;
    }

    var div = document.getElementById('count_down_div');

    if (div == null || div == undefined) {
        div = document.createElement('div');
        div.id = 'count_down_div';
        div.style.position = 'absolute';
        div.style.width = '150px';
        div.style.height = '150px';
        div.style.left = '150px';
        div.style.top = '150px';
        SingleGame.setOpacity(div, 100);
        if (this.StartGameCount != 4) {
            div.innerHTML = this.StartGameCount;
        }
        div.style.fontSize = '150px';
        div.style.color = 'red';
        SingleGame.canvas.appendChild(div);
    } else {
        div.style.position = 'absolute';
        div.innerHTML = SingleGame.StartGameCount;
    }

    SingleGame.StartGameCount--;

    if (SingleGame.StartGameCount < 0) {
        SingleGame.gameReady();
        SingleGame.canvas.removeChild(div);
        SingleGame.StartGameCount = 4;
    } else {
        setTimeout('SingleGame.gameStartCountDown();', 1000);
    }
},

randomizeBlockAnimation:function() {
    if (this.stopped) {
        return;
    }

    if (this.gameStarted) {
        this.setNumbers();
        SingleGame.startTime = new Date();
        return;
    }

    for ( var i = 0; i < 5; ++i) {
        for ( var j = 0; j < 5; ++j) {
            var id = (i * 5) + j;
            var div = document.getElementById('block_' + id);
            SingleGame.setImage(div.id, Math.floor(Math.random() * 26));
        }
    }

    setTimeout('SingleGame.randomizeBlockAnimation();', 50);
},

init:function () {
    if (SingleGame.socket==null) {
        SingleGame.initSocket();
    }
    SingleGame.expectValues = SingleGame.getRandomArray(25);
    SingleGame.imageSet = Math.floor(Math.random()*5) + 1;

    SingleGame.stopped = false;
    SingleGame.StartGameCount = 4,
    SingleGame.gameStarted = false,
    SingleGame.startTime = 0,
    
    SingleGame.canvas = document.getElementById('single_canvas');
    SingleGame.timeCountDiv = document.getElementById('time_count');
    
    var seq = Math.floor(Math.random()*9);
//    var imgUrl = 'ball'+seq + '.png';

    seq = Math.floor(Math.random()*6);
    var bgUrl = './background/background' + seq + ".jpg";
    
    $('#body').css('background-image','url("' + bgUrl + '")').attr("onselectstart","return false;");
    
    for ( var i = 0; i < 5; ++i) {
        for ( var j = 0; j < 5; ++j) {
            var id = i * 5 + j;
            var div = document.getElementById("block_" + id);
            if (div == null || div == undefined) {
                div = document.createElement('div');
                div.id = 'block_' + id;
            }
            div.style.position = 'absolute';
            div.style.width = '80px';
            div.style.height = '80px';
            div.style.left = i * 80 + 'px';
            div.style.top = j * 80 + 'px';
            div.style.visibility = "visible";
            div.innerHTML = '<img id="click_image_' + div.id + '" src="" width="80px" height="80px"/>';

//            div.style.backgroundImage = 'url("' + imgUrl + '")';
//            div.style.backgroundRepeat = "no-repeat";

            div.style.color = 'black';
            div.style.fontWeight = 'bold';
            div.style.fontSize = '36px';
            div.style.textAlign = 'center';

            SingleGame.canvas.appendChild(div);
        }
    }

    setTimeout('SingleGame.gameStartCountDown();', 50);
    setTimeout('SingleGame.randomizeBlockAnimation();', 50);
},


setMusic:function (filename) {
    /*
    var music = document.getElementById('music');
    var parent = music.parentNode;

    parent.removeChild(music);

    music.innerHTML = '<embed src="' + filename + '" />'
            + '<bgsound loop="0" src="' + filename + '">';
    parent.appendChild(music);
    */
}
};