<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
	<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<link rel="stylesheet" href="../../css/ui-darkness/jquery-ui-1.8.16.custom.css" type="text/css" />
<script type="text/javascript" src="../../js/yahoo-min.js"></script>
<script type="text/javascript" src="../../js/json-min.js"></script>
<script type="text/javascript" src="../../js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="../../js/jquery-ui-1.8.16.custom.min.js"></script>
<script src="http://106.187.43.45:54321/socket.io/socket.io.js"></script>
<script type="text/javascript" src="./js/gameclient.js"></script>

    <script src="js/swfobject.js"></script>
    <script>
    </script>

<style type="text/css"> 
    .ui-dialog .ui-dialog-buttonpane  {text-align:center;}
    .ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset {float:none;}
</style> 

</head>
<body id="body" onload="Client.init();" style='font-family:"Microsoft YaHei",Arial;background-color:black;'>

<div id="LOADING_DIV" style="color:white;font-size:30px;">
与游戏服务器连接中，请稍候...<br/>
使用Chrome/Firefox以获得更快连接速度
</div>


<div id='GAME_ROOM_DIV' style='width:800px; visibility:hidden'>

<div id="new_room_div" style='position:absolute;left:10px;top:55px;font-size:22px;color:#80FF00;background-color:black;'>
<input id='new_game_room_id' size=20 maxlength=20 value='请输入游戏房间名字' onfocus="this.value='';this.style.color='black';" style='color:#AAA'></input>
<input type="button" value="建立游戏" onclick='Client.createNewGame();'></input><br/>
<span style='font-size:14px;'>游戏房间名将作为你建立的游戏的唯一标识，其它玩家可在列表看到该房间并加入。房间名不超过20字且只能是数字、英文字母或者标准中文</span>
<hr/>
</div>

<div id='room_list' style='position:absolute;left:10px;top:150px;font-size:16px;color:white;background-color:black;'>
</div>

</div>


<div id='GAME_CANVAS_DIV' style='position:absolute;left:-10000px;top:-10000px;font-size:16px;'>

    <div style="position:absolute;top:30px;left:30px;">
    <div id="altContent">
        <h1>row5</h1>
        <p><a href="http://www.adobe.com/go/getflashplayer">Get Adobe Flash player</a></p>
    </div>
    </div>

    <div style="position:absolute;left:550px; top: 20px; width:250px;height:100px;cursor:pointer;">
    <input type='button' value='退出' onclick="exitGame();">
    <input type='button' value='重新开始' onclick="restartGame();">
    </div>
    
    <div id="score_list" style="position:absolute;left:550px; top: 60px; width:250px;height:250px;font-size:12px;text-align:left;color:white;overflow:auto;" onselectstart='return false;';>
    等待其它玩家加入...
    </div>
    
    <div id="chat_div" style="position:absolute;left:550px; top: 320px; width:250px;height:250px;font-size:12px;text-align:left;color:white;" onselectstart='return false;';>
    
        <hr>
        
        <div id="chat_messages" style='width:250px; height:150px; overflow:auto;'>
        </div>
        <br/>
        <textarea id="chat_input_message" cols="20" rows="3"></textarea><br/>
        <input type='button' value='送出' onclick='sendChatMessage();'>
    
    </div>

</div>


</body>

</html>
