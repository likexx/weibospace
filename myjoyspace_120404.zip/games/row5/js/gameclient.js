
var gameState = {
        room_id:0,
        uid:0,
        isPlayer1:false
};

var UserCache={};

var CurrentUser = {
  uid: null,
  username:null,
  image: null
};


function restartGame() {
    Client.socket.emit('RESTART_GAME', {'room_id': gameState.room_id, 'uid':CurrentUser.uid});
}

function exitGame() {
    Client.socket.emit('EXIT_GAME',{'roomId':gameState.room_id});
    UI.initRoomList();
}


function htmlEncode(str) {
    
    return String(str)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
}

function sendChatMessage() {
    var data = $('#chat_input_message').val();
    data = htmlEncode(data);
    
    var message = {uid:CurrentUser.uid, room_id:gameState.room_id, value: data};

    Client.socket.emit('CHAT_MESSAGE', message);
    $('#chat_input_message').val("");
    
}

function initFlashGame() {
    
    var flashvars = {
    };
    var params = {
        menu: "false",
        scale: "noScale",
        allowFullscreen: "true",
        allowScriptAccess: "always",
        bgcolor: "",
        wmode: "direct" // can cause issues with FP settings & webcam
    };
    var attributes = {
        id:"row5"
    };
    swfobject.embedSWF(
        "row5.swf", 
        "altContent", "500px", "500px", "10.0.0", 
        "expressInstall.swf", 
        flashvars, params, attributes);

}


var Client = {
        socket: null,
        callbacks:{},
        connected: false,
        game: null,
        
        init:function() {
            
            $('#chat_input_message').val();
            
            $('#chat_input_message').keypress(function(e) {
                if (e.keyCode == 13){
                    sendChatMessage();
                }
            });
            
            $.post('/getuser.php',{}, function(data) {
                var user=YAHOO.lang.JSON.parse(data);
                CurrentUser.uid = user._id;
                CurrentUser.username = user.username;
                CurrentUser.image = user.image;
            });
            
            initFlashGame();
            Client.game = document.getElementById("row5");
            
            this.callbacks['UPDATE_ROOMS'] = this.onUpdateRooms;
            this.callbacks['USER_JOIN'] = this.onUserJoin;
            this.callbacks['UPDATE_SCORE'] = this.onUpdateScore;    
            this.callbacks['CHAT_MESSAGE'] = this.onChatMessage;    
            this.callbacks['UPDATE_ROOM_INFO'] = this.onUpdateRoomInfo;    
            this.callbacks['START_GAME'] = this.onStartGame;
            this.callbacks['ACTION'] = this.onAction;    
            this.callbacks['EXIT_GAME'] = this.onExitGame;
            
            this.socket = io.connect('http://106.187.43.45:54321/row5');

            
            this.socket.on('CONNECTED', function(data){
                Client.connected = true;
                $('#LOADING_DIV').remove();
                $('#GAME_ROOM_DIV').css('visibility','visible');
                Client.loadRooms();
            });

            
            this.socket.on('WAIT_PLAYER', function(data){
                gameState.room_id = data.roomId;

                $('#GAME_ROOM_DIV').css({
                    'position': 'absolute',
                    'top':-10000,
                    'left':-10000
                    });

                $('#GAME_CANVAS_DIV').css({
                    'position': 'absolute',
                    'top':0,
                    'left':0,
                    });
                
                Client.game.reset("");
            });
            
            
            this.socket.on('message', function(msg) {  

                var d = YAHOO.lang.JSON.parse(msg);
                var cmd = d.cmd;
                if (Client.callbacks[cmd]!=undefined && Client.callbacks[cmd] != null) {
                    Client.callbacks[cmd](d);
                }

            });

        },
        
        sendAction:function(value) {
            this.socket.emit('action', {
                'roomId':gameState.room_id,
                'value': value});
        },
        
        onAction:function(data) {
            var value = data.value;
            
            Client.game.placePiece("place," + value); 

        },
        
        
        validateRoomId: function(roomId) {
            var invalidLetters=['<','>','/','\\', '"','&','[',']'];
            for(i in invalidLetters){
                var c = invalidLetters[i];
                if (roomId.indexOf(c)>=0){
                    return false;
                }
            }
            
            return true;
        },
        
        createNewGame:function() {
            if (CurrentUser.uid==null) {
                return;
            }
            var roomId=$('#new_game_room_id').val();
            if (!Client.validateRoomId(roomId)) {
                return;
            }   
            
            this.socket.emit('CREATE_NEW_ROOM', {'uid':CurrentUser.uid, 'roomId': roomId, 'game':'row5','max':2});
        },
        
        loadRooms:function() {
            Client.socket.emit('GET_ROOMS',{});
        },
        
        onUpdateRooms: function(d) {
            UI.showRooms(d.rooms);
        },
        
        joinRoom:function(roomid) {
            this.socket.emit('JOIN_ROOM',{
                'roomId':roomid,
                'uid':CurrentUser.uid
            });
            
        },
        
         
        
        onStartGame:function(data) {
            
            gameState.room_id = data.data.room_id;

            $('#GAME_ROOM_DIV').css({
                'position': 'absolute',
                'top':-10000,
                'left':-10000
                });

            $('#GAME_CANVAS_DIV').css({
                'position': 'absolute',
                'top':0,
                'left':0,
                });

            
            for(i in data.data.players) {
                var player = data.data.players[i];
                if (player.id==CurrentUser.uid) {
                    var color = "" + player.color;
                    Client.game.startGame(color);
                }
            }
            
            $('#score_list').html('进行中...');
            
        },
        
        onExitGame:function(data) {
          exitGame();  
        },

        onUserJoin:function(data) {
            gameState.room_id = data.roomId;
            var userid = data.userid;
            var user = UserCache[userid];
            if ( user != null && user!=undefined) {
                UI.showUserJoinDialog(user);
                return;
            }
            
            $.post('/getuser.php', {uid:userid}, function(data){
                var user=YAHOO.lang.JSON.parse(data);
                UserCache[user._id]=user;
                UI.showUserJoinDialog(user);
            });
            
        },
        
        onRemoveNumber:function(d) {
            var block = $('#block_' + d.index);
            block[0].style.backgroundImage = "";
            block[0].innerHTML = '<img src="./Explosion.gif" width="80px" onselectstart="return false;"/>';
            setTimeout('UI.removeExplosion("' + block[0].id + '");', 800);

            if (d.expectValue < 0) {
                stopGame();
            } else {
                $('#expect_value').html(getTarget(d.expectValue));
            }

            UI.updateScore(d.players);

        },

        onUpdateScore:function(d) {
            UI.updateScore(d.players);
        },
        
        onChatMessage:function(data) {
            var user = data.user;
            var message = data.message;
            
            var prevContent = $('#chat_messages').html();

            var content = "<div>" +
            "<table><tr><td><img src='" + user.image + "' width='32px' height='32px'/></td><td>" +
            message +
            "</td></table></div>" + prevContent;
            
            $('#chat_messages').html(content);

        }

        
}


var UI={
        showRooms:function(rooms) {
            var content = "<table>";
            var len = rooms.length;
            for(var i=0;i<len;++i) {
                if (i%4==0) {
                    content+="<tr>";
                }
                
                var room = rooms[i];
           
                content+="<td style='width:200px;height:100px;'><div id='room_" + room.id + 
                         "' style='cursor:pointer;' onmouseover='this.style.color=\"green\";' onmouseout='this.style.color=\"\";' onclick='Client.joinRoom(\"" + room.id + "\");'>" + 
                         room.id.replace("row5_","") + "<br/>加入游戏</div></td>";

                
                if ((i+1)%4==0) {
                    content+="</tr>";
                }
            }
            $('#room_list').html(content);
        },
        
        initRoomList:function() {
            $('#canvas').html('');
            $('#score_list').html('');
            $('#chat_messages').html('');
            $('#chat_input_message').val('');
            
            $('#GAME_ROOM_DIV').css({
                'position': 'absolute',
                'top':0,
                'left':0
                });
            
            $('#GAME_CANVAS_DIV').css({
                'position': 'absolute',
                'top':-10000,
                'left':-10000
                });

            $('body').css('background','black');
        
        },

        showUserJoinDialog:function(user) {
            var div = $('<div id="ROOM_READY_DIALOG">');
            var content = "<img src='" + user.image + "'>" + user.username + "加入</br>" +
            "";
            
            div.css({
                'width':320,
                'height':240
            }).html(content).appendTo('body').dialog({
                    show: "explode",
                    hide: "explode",
                    width: 360,
                    height: 260,
                    position: [520,120],
                    title: "有新对手加入",
                    
                    close: function(event, ui) {
//                        setMusic(battleMusic[Math.floor(Math.random() * 3)]);
                        setTimeout('restartGame();', 500);
                    },
                    
                    buttons: [
                              {
                                  text: "开始对战",
                                  click: function() { $(this).dialog("close"); }
                              },

                          ]
            });
        
        }
}