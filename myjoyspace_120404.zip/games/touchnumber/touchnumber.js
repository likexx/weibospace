WEB_SOCKET_SWF_LOCATION = "WebSocketMain.swf";
// Set this to dump debug message from Flash to console.log:
WEB_SOCKET_DEBUG = true;


var StartGameCount = 4;
var canvas = null;
var timeCountDiv = null;
var gameStarted = false;
var clicked = {};
var expectedValue = 1;

var startTime = 0;

var battleMusic = [ './music/battle1.mid', './music/battle2.mid',
        './music/battle3.mid' ];
var victoryMusic = './music/win.mid';

var socket = null;

function initSocket() {
    socket = io.connect('http://106.187.43.45:54321/singleplayer');
    
    socket.on('CONNECTED', function(data){
        $.post('./jointouchnumber.php',{});
    });
    
    socket.on('JOIN_GAME', function (data) {
        console.log(data);
        var content = "<img src='" + data.image + "'/>" +data.username + " 加入游戏";
        showGameMessage(content);
      });       

    socket.on('NEW_SCORE', function (data) {
        var content = "<img src='" + data.image + "'/>" +data.username + " 用时 " + data.score + "秒";

        showGameMessage(content);
      });       

}

function publishScore(score) {
    $.post('./publishscore.php',{'gamename':'touchnumber','score':score});
    
}

function showGameMessage(data) {
    var content = $('#messages').html();
    content = data+ '<br/>' + content;
    $('#messages').html(content);
}

function getRandomArray(n) {
    var arr = [];
    for ( var i = 0; i < n; ++i) {
        arr.push(i + 1);
    }

    for ( var i = n - 1; i > 0; --i) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    return arr;

}

function getRandomNumber() {
    return Math.random() * 100000;
}


function stopGame() {
    for ( var i = 0; i < 5; ++i) {
        for ( var j = 0; j < 5; ++j) {
            var id = (i * 5) + j;
            var div = document.getElementById('block_' + id);

            canvas.removeChild(div);
        }
    }
    setMusic(victoryMusic);

    document.getElementById('next_value').innerHTML = '';
    gameStarted = false;
    StartGameCount = 4;

    var currentTime = new Date();
    var timeScore = (currentTime.getTime() - startTime.getTime()) / 1000.0;

    publishScore(timeScore);

    var content = "<div style='color:white;'>使用时间: " + timeScore + "秒<br/></div>";

    
    var offset = $('#canvas').offset();

    var div = $('<div id="SCORE_DIALOG">');
    
    div.css({
        'width':320,
        'height':240,
    }).html(content).appendTo('body').dialog({
            show: "explode",
            hide: "explode",
            width: 360,
            height: 260,
            position: [offset.left+50,offset.top+20],
            title: "游戏结果",
            
            close: function(event, ui) {
                setMusic(battleMusic[Math.floor(Math.random() * 3)]);
                setTimeout('init();', 500);
            },
            
            buttons: [
                      {
                          text: "关闭",
                          click: function() { $(this).dialog("close"); }
                      }
                  ]
    });
}

function removeExplosion(id) {
    $('#' + id).css('visibility','hidden');
}

function onClickAtNumber() {
    var value = parseInt(this.firstChild.innerHTML);

    if (value != expectedValue) {
        return;
    }

    this.style.backgroundImage = "";
    this.innerHTML = '<img src="./Explosion.gif" width="80px" onselectstart="return false;"/>';
    setTimeout('removeExplosion("' + this.id + '");', 800);

    expectedValue++;
    if (expectedValue > 25) {
        expectedValue = 1;

        stopGame();
    } else {
        document.getElementById('next_value').innerHTML = '<span style="color:red;font-weight:bold;">&nbsp;&nbsp;'
                + expectedValue + '</span>';
    }
}

function setOpacity(e, value) {
    e.style.opacity = value / 100;
    e.style.filter = 'alpha(opacity=' + value + ')';
}

function updateTimeCount() {
    if (!gameStarted) {
        timeCountDiv.innerHTML = "";
        return;
    }
    var currentTime = new Date();
    var timeScore = (currentTime.getTime() - startTime.getTime()) / 1000.0;
    timeCountDiv.innerHTML = '游戏计时: ' + timeScore;
    setTimeout('updateTimeCount();', 100);
}

function setDivInnerNumber(div, value) {
    div.innerHTML = '<div style="position:relative;top:12px;" onselectstart="return false;">'
            + value + '</div>';
}

function setNumbers() {
    var randomNumbers = getRandomArray(25);

    for ( var i = 0; i < 5; ++i) {
        for ( var j = 0; j < 5; ++j) {
            var id = (i * 5) + j;
            var div = document.getElementById('block_' + id);
            setDivInnerNumber(div, randomNumbers[id]);
            div.style.cursor = 'crosshair';
            div.onmousedown = onClickAtNumber;
            div.onselectstart = function() {
                return false;
            };
        }
    }
    document.getElementById('next_value').innerHTML = '<span style="color:red;font-weight:bold;">'
            + expectedValue + '</span>';
    setTimeout('updateTimeCount();', 100);
}

function gameReady() {
    gameStarted = true;
    expectedValue = 1;
    cliecked = {};
}

function gameStartCountDown() {
    var div = document.getElementById('count_down_div');

    if (div == null || div == undefined) {
        div = document.createElement('div');
        div.id = 'count_down_div';
        div.style.position = 'absolute';
        div.style.width = '150px';
        div.style.height = '150px';
        div.style.left = '150px';
        div.style.top = '150px';
        setOpacity(div, 100);
        if (StartGameCount != 4) {
            div.innerHTML = StartGameCount;
        }
        div.style.fontSize = '150px';
        div.style.color = 'red';
        canvas.appendChild(div);
    } else {
        div.style.position = 'absolute';
        div.innerHTML = StartGameCount;

    }

    StartGameCount--;

    if (StartGameCount < 0) {
        gameReady();
        canvas.removeChild(div);
        StartGameCount = 4;
    } else {
        setTimeout('gameStartCountDown();', 1000);
    }
}

function randomizeBlockAnimation() {
    if (gameStarted) {
        setNumbers();
        startTime = new Date();
        return;
    }

    for ( var i = 0; i < 5; ++i) {
        for ( var j = 0; j < 5; ++j) {
            var id = (i * 5) + j;
            var div = document.getElementById('block_' + id);
            setDivInnerNumber(div, Math.floor(Math.random() * 26));
        }
    }

    setTimeout('randomizeBlockAnimation();', 50);
}

function init() {
    if (socket==null) {
        initSocket();
    }
    canvas = document.getElementById('canvas');
    timeCountDiv = document.getElementById('time_count');
    
    
    
    var seq = Math.floor(Math.random()*9);
    var imgUrl = 'ball'+seq + '.png';

    seq = Math.floor(Math.random()*6);
    var bgUrl = './background/background' + seq + ".jpg";
    
    $('#body').css('background-image','url("' + bgUrl + '")').attr("onselectstart","return false;");
    
    for ( var i = 0; i < 5; ++i) {
        for ( var j = 0; j < 5; ++j) {
            var id = i * 5 + j
            var div = document.getElementById("" + id);
            if (div == null || div == undefined) {
                div = document.createElement('div');
            }
            div.id = 'block_' + id;
            div.style.position = 'absolute';
            div.style.width = '80px';
            div.style.height = '80px';
            div.style.left = i * 80 + 'px';
            div.style.top = j * 80 + 'px';
            div.style.visibility = "visible";

            div.style.backgroundImage = 'url("' + imgUrl + '")';
            div.style.backgroundRepeat = "no-repeat";

            div.style.color = 'black';
            div.style.fontWeight = 'bold';
            div.style.fontSize = '36px';
            div.style.textAlign = 'center';

            canvas.appendChild(div);
        }
    }

    setTimeout('gameStartCountDown();', 50);
    setTimeout('randomizeBlockAnimation();', 50);
}


function setMusic(filename) {
    var music = document.getElementById('music');
    var parent = music.parentNode;

    parent.removeChild(music);

    music.innerHTML = '<embed src="' + filename + '" />'
            + '<bgsound loop="0" src="' + filename + '">';
    parent.appendChild(music);

}