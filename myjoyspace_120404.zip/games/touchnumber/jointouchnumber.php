<?php 
require_once('../../phpservice/class/node.php');

$uid = $_COOKIE['uid'];

$node= new Node();

$payload=array(
    'uid'=>$uid
);

$node->dataPush($uid, 'JOIN_GAME',$payload);

?>