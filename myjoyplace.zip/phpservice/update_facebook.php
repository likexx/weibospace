
<?php 
require_once('./class/help.php');

HELP::updateNext();

?>